package com.lp.lpmusickitdemo.musicsource.loc_music;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.core.device.LPDevice;
import com.linkplay.core.listener.LPDevicePlayerListener;
import com.linkplay.core.status.LPPlayQueueType;
import com.linkplay.lpmdpkit.LPMDPKitManager;
import com.linkplay.lpmdpkit.LPPlaySourceType;
import com.linkplay.lpmdpkit.bean.LPPlayHeader;
import com.linkplay.lpmdpkit.bean.LPPlayItem;
import com.linkplay.lpmdpkit.bean.LPPlayMusicList;
import com.linkplay.mediainfo.LPMediaInfo;
import com.linkplay.medialib.LPMSLibraryManager;
import com.linkplay.medialib.LPMSLibraryPlayItem;
import com.linkplay.medialib.LPSearchMediaResultListener;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.UIApplication;
import com.lp.lpmusickitdemo.musicsource.PlayControlActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/08/21 11:21
 * @Description: TODO{}
 */
public class FragLocMusicDetails extends FragBase {

    private static final String TAG = "FragLocMusicDetails";

    TextView tv_title;
    RecyclerView recyclerview;
    List<LPMSLibraryPlayItem> songsList = new ArrayList<>();
    LPDevice mLPDevice;

    LocMusicDetailsAdapter adapter;

    CheckItemType type;
    LPMSLibraryPlayItem playItem;
    LPPlayHeader playHeader;

    private static final int UPDATE_SONGS_LIST = 1;
    Handler uihd = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            int what = msg.what;

            if (what == UPDATE_SONGS_LIST) {

                if (adapter != null) {
                    adapter.setCurrList(songsList);
                    adapter.notifyDataSetChanged();
                }

            }
        }
    };

    public void setPlayItem(CheckItemType type, LPMSLibraryPlayItem playItem) {
        this.type = type;
        this.playItem = playItem;
    }

    @SuppressLint("WrongConstant")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_loc_music_details, null);

        tv_title = cview.findViewById(R.id.tv_title);
        recyclerview = cview.findViewById(R.id.recyclerview);


        if (playItem != null) {
            if (type == CheckItemType.ARTIST_RADIO_TYPE)
                tv_title.setText(playItem.getTrackArtist());
            else if (type == CheckItemType.ALBUM_RADIO_TYPE)
                tv_title.setText(playItem.getAlbumName());
            else if (type == CheckItemType.SONGLIST_RADIO_TYPE)
                tv_title.setText(playItem.getSonglist());
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        adapter = new LocMusicDetailsAdapter(getActivity());

        adapter.setOnItemClickListener(new LocMusicDetailsAdapter.IOnItemClickListener() {
            @Override
            public void onItemClick(int pos) {

                clickSongItem(pos);
            }

            @Override
            public void onMoreClick(int pos, LPMSLibraryPlayItem item) {

                nextPlay(pos, item);
            }
        });
        recyclerview.setAdapter(adapter);

        initPlayHeader();

        if (type == CheckItemType.ARTIST_RADIO_TYPE)
            searchArtistMusics();
        else if (type == CheckItemType.ALBUM_RADIO_TYPE)
            searchAlbumMusics();
        else if (type == CheckItemType.SONGLIST_RADIO_TYPE)
            searchSonglistMusics();

        return cview;
    }

    @Override
    public void onResume() {
        super.onResume();

        mLPDevice = UIApplication.currDevice;
    }

    @Override
    public void onBack() {
        super.onBack();
        FragUtil.popBack(getActivity());
    }

    private void initPlayHeader() {

        if (playHeader == null)
            playHeader = new LPPlayHeader();
        playHeader.setCurrentPage(1);
        playHeader.setPerPage(50);
    }

    private void searchArtistMusics() {

        String searchKey = tv_title.getText().toString();

        LPMSLibraryManager.getInstance(UIApplication.instance)
                .searchArtistSongs(searchKey, playHeader,

                        new LPSearchMediaResultListener() {
                            @Override
                            public void success(LPPlayMusicList musicList) {

                                if (musicList != null) {

                                    List<LPPlayItem> playItemList = musicList.getList();
                                    if (playItemList != null) {

                                        Object[] items = playItemList.toArray();
                                        List<Object> objectList = Arrays.asList(items);
                                        List<LPMSLibraryPlayItem> locPlayItemList = (List) objectList;

                                        if (songsList == null)
                                            songsList = new ArrayList<>();

                                        songsList.addAll(locPlayItemList);
                                    }

                                    playHeader = musicList.getHeader();
                                    playHeader.setCurrentPage(playHeader.getCurrentPage() + 1);
                                }

                                uihd.sendEmptyMessage(UPDATE_SONGS_LIST);
                            }

                            @Override
                            public void failure(Exception e) {

                             }
                        });
    }


    private void searchAlbumMusics() {

        String searchKey = tv_title.getText().toString();

        LPMSLibraryManager.getInstance(UIApplication.instance)
                .searchAlbumSongs(searchKey, playHeader,

                        new LPSearchMediaResultListener() {
                            @Override
                            public void success(LPPlayMusicList musicList) {

                                if (musicList != null) {

                                    List<LPPlayItem> playItemList = musicList.getList();
                                    if (playItemList != null) {

                                        Object[] items = playItemList.toArray();
                                        List<Object> objectList = Arrays.asList(items);
                                        List<LPMSLibraryPlayItem> locPlayItemList = (List) objectList;

                                        if (songsList == null)
                                            songsList = new ArrayList<>();

                                        songsList.addAll(locPlayItemList);
                                    }

                                    playHeader = musicList.getHeader();
                                    playHeader.setCurrentPage(playHeader.getCurrentPage() + 1);
                                }

                                uihd.sendEmptyMessage(UPDATE_SONGS_LIST);
                            }

                            @Override
                            public void failure(Exception e) {

                             }
                        });
    }

    private void searchSonglistMusics() {

        String searchKey = tv_title.getText().toString();

        LPMSLibraryManager.getInstance(UIApplication.instance)
                .searchSonglistSongs(searchKey, playHeader,

                        new LPSearchMediaResultListener() {
                            @Override
                            public void success(LPPlayMusicList musicList) {

                                if (musicList != null) {

                                    List<LPPlayItem> playItemList = musicList.getList();
                                    if (playItemList != null) {

                                        Object[] items = playItemList.toArray();
                                        List<Object> objectList = Arrays.asList(items);
                                        List<LPMSLibraryPlayItem> locPlayItemList = (List) objectList;

                                        if (songsList == null)
                                            songsList = new ArrayList<>();

                                        songsList.addAll(locPlayItemList);
                                    }

                                    playHeader = musicList.getHeader();
                                    playHeader.setCurrentPage(playHeader.getCurrentPage() + 1);
                                }

                                uihd.sendEmptyMessage(UPDATE_SONGS_LIST);
                            }

                            @Override
                            public void failure(Exception e) {

                             }
                        });
    }

    private String getMediaData(int pos, boolean nextPlay) {

        List<LPMSLibraryPlayItem> mediaInfoList = null;
        if(nextPlay)
            mediaInfoList = Arrays.asList(adapter.getCurrList().get(pos));
        else
            mediaInfoList = adapter.getCurrList();

        LPPlayHeader playHeader = new LPPlayHeader();
        if(nextPlay)
            playHeader.setHeadTitle(LPPlayQueueType.LP_CURRENT_QUEUE.getValue());
        else
            playHeader.setHeadTitle("My Music");

        playHeader.setMediaType(LPPlayHeader.LPPlayMediaType.LP_SONGLIST_LOCAL);
        playHeader.setMediaSource(LPPlaySourceType.LP_LOCALMUSIC);

        LPPlayMusicList lpPlayMusicList = new LPPlayMusicList();
        lpPlayMusicList.setHeader(playHeader);
        lpPlayMusicList.setIndex(pos);
        lpPlayMusicList.setList(mediaInfoList);

        String data = LPMDPKitManager.getInstance().playMusicSingleSource(lpPlayMusicList);

        return data;
    }

    private void nextPlay(int pos, LPMSLibraryPlayItem item){

        String mediaData = getMediaData(pos, true);

        LPMediaInfo mediaInfo = new LPMediaInfo();
        mediaInfo.setAlbum(item.getAlbumName());
        mediaInfo.setArtist(item.getTrackArtist());
        mediaInfo.setTitle(item.getTrackName());

        UIApplication.currDevice.getPlayer().nextPlay(mediaData,
                mediaInfo,
                new LPDevicePlayerListener() {
                    @Override
                    public void onSuccess(String result) {

                        uihd.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "next play success", Toast.LENGTH_SHORT).show();
                            }
                        });

                        Log.i(TAG, "success");
                    }

                    @Override
                    public void onFailure(Exception e) {

                        uihd.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "next play failed", Toast.LENGTH_SHORT).show();
                            }
                        });

                        Log.i(TAG, "failed");
                    }
                });
    }

    private void clickSongItem(int pos) {

        String mediaData = getMediaData(pos, false);

        UIApplication.currDevice.getPlayer().playAudio(mediaData,
                new LPDevicePlayerListener() {

                    @Override
                    public void onSuccess(String result) {

                        Intent intent = new Intent(getActivity(), PlayControlActivity.class);
                        startActivity(intent);
                     }

                    @Override
                    public void onFailure(Exception e) {
                     }
                });
    }

}
