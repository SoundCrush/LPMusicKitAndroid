package com.lp.lpmusickitdemo.musicsource;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;


import com.lp.lpmusickitdemo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/08/06 11:40
 * @Description: TODO{}
 */
public class SourceMainAdapter extends RecyclerView.Adapter<SourceMainAdapter.SourceViewHolder> {

    List<SourceItem> currList = new ArrayList<>();

    private Context mContext;

    public SourceMainAdapter(Context context) {
        mContext = context;
    }

    public void setCurrList(List<SourceItem> list) {
        this.currList = list;
    }

    public List<SourceItem> getCurrList() {
        return currList;
    }

    @NonNull
    @Override
    public SourceViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item_source_main, null);

        SourceViewHolder viewHolder = new SourceViewHolder(view);

        return viewHolder;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(@NonNull SourceViewHolder sourceViewHolder, final int i) {

        SourceItem item = currList.get(i);

        sourceViewHolder.tv_title.setText(item.name);

        sourceViewHolder.container.setBackground(mContext.getDrawable(R.drawable.selector_item_bg));

        sourceViewHolder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (listener != null)
                    listener.onItemClick(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return currList == null ? 0 : currList.size();
    }


    private IOnItemClickListener listener;

    public void setOnItemClickListener(IOnItemClickListener listener) {
        this.listener = listener;
    }

    public interface IOnItemClickListener {
        void onItemClick(int pos);
    }

    public static class SourceItem {

        String name = "";
        KEY key;

        public SourceItem(String name, KEY key) {
            this.name = name;
            this.key = key;
        }

        enum KEY {
            LOC_MUSIC,
            NAS,
            AMAZON_MUSIC,
            TIDAL,
            PLAY_CONTROL,
            ALARM,
            PRESET,
            TUNEIN,
            USBDISK,
            SWITCH_MODE,
            DEVICE_SETTING
        }
    }

    public static class SourceViewHolder extends RecyclerView.ViewHolder {

        private TextView tv_title;
        private View container;

        public SourceViewHolder(@NonNull View itemView) {
            super(itemView);

            container = itemView;
            tv_title = itemView.findViewById(R.id.tv_title);
        }
    }
}
