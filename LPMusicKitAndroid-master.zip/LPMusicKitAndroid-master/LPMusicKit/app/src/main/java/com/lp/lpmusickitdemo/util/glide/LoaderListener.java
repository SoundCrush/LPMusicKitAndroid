package com.lp.lpmusickitdemo.util.glide;

/**
 * @author leyunrui-wiimu
 * @version v1.0
 * @date 上午10:58 18-07-2017
 * @Description: TODO{}
 */

public interface LoaderListener {

    void onSuccess();
    void onError();
}
