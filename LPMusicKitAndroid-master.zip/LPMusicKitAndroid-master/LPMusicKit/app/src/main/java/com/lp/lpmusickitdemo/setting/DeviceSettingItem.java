package com.lp.lpmusickitdemo.setting;

import java.io.Serializable;

public class DeviceSettingItem implements Serializable {

    public String strBtnText = "";
    public String strLabel = "";//label
    public String strValue = "";//context
    public ENUM_TYPE type = ENUM_TYPE.none;

    public enum ENUM_TYPE {
        none,
        channel,
        ssid_hide,
        eq_http,
        eq_mcu,
        spotify_account,
        reset_device,
    }
}
