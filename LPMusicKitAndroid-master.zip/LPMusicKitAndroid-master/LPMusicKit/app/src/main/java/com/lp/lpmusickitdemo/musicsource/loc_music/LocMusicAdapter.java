package com.lp.lpmusickitdemo.musicsource.loc_music;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.medialib.LPMSLibraryPlayItem;
import com.lp.lpmusickitdemo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/31 19:19
 * @Description: TODO{}
 */
public class LocMusicAdapter extends RecyclerView.Adapter<LocMusicAdapter.LocMusicViewHolder> {

    List<LPMSLibraryPlayItem> currList = new ArrayList<>();

    private Context mContext;
    private CheckItemType radioType;

    public LocMusicAdapter(Context context) {
        mContext = context;
    }

    public void setCurrList(CheckItemType type, List<LPMSLibraryPlayItem> list) {
        radioType = type;
        this.currList = list;
    }

    public List<LPMSLibraryPlayItem> getCurrList() {
        return currList;
    }

    @NonNull
    @Override
    public LocMusicViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int pos) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item_loc_music_main, null);

        LocMusicViewHolder viewHolder = new LocMusicViewHolder(view);

        return viewHolder;
    }

    @SuppressLint("NewApi")
    @Override
    public void onBindViewHolder(@NonNull LocMusicViewHolder locMusicViewHolder, final int pos) {

        LPMSLibraryPlayItem data = currList.get(pos);

        if (radioType == CheckItemType.SONGS_RADIO_TYPE) {
            locMusicViewHolder.tv_title.setText(data.getTrackName());
            locMusicViewHolder.tv_more.setVisibility(View.GONE);
            locMusicViewHolder.tv_sub_title.setText(data.getTrackArtist());

            locMusicViewHolder.iv_more.setVisibility(View.VISIBLE);
            locMusicViewHolder.iv_more.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null)
                        listener.onMoreClick(pos, data);
                }
            });

        } else if (radioType == CheckItemType.ARTIST_RADIO_TYPE) {
            locMusicViewHolder.tv_title.setText(data.getTrackArtist());
            locMusicViewHolder.tv_sub_title.setText("" + data.getSongCount());
            locMusicViewHolder.tv_more.setVisibility(View.VISIBLE);
            locMusicViewHolder.iv_more.setVisibility(View.GONE);
        } else if (radioType == CheckItemType.ALBUM_RADIO_TYPE) {
            locMusicViewHolder.tv_title.setText(data.getAlbumName());
            locMusicViewHolder.tv_sub_title.setText(data.getTrackArtist());
            locMusicViewHolder.tv_more.setVisibility(View.VISIBLE);
            locMusicViewHolder.iv_more.setVisibility(View.GONE);
        } else if (radioType == CheckItemType.SONGLIST_RADIO_TYPE){
            locMusicViewHolder.tv_title.setText(data.getSonglist());
            locMusicViewHolder.tv_sub_title.setText("" + data.getSongCount());
            locMusicViewHolder.tv_more.setVisibility(View.VISIBLE);
            locMusicViewHolder.iv_more.setVisibility(View.GONE);
        }

        locMusicViewHolder.container.setBackground(mContext.getDrawable(R.drawable.selector_item_bg));

        locMusicViewHolder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (listener != null)
                    listener.onItemClick(radioType, pos);
            }
        });
    }

    @Override
    public int getItemCount() {

        return currList == null ? 0 : currList.size();
    }


    private IOnItemClickListener listener;

    public void setOnItemClickListener(IOnItemClickListener listener) {
        this.listener = listener;
    }

    public interface IOnItemClickListener {
        void onItemClick(CheckItemType type, int pos);
        void onMoreClick(int pos, LPMSLibraryPlayItem item);
    }

    public static class LocMusicViewHolder extends RecyclerView.ViewHolder {

        public View container;
        public TextView tv_title, tv_sub_title, tv_more;
        public ImageView iv_more;

        public LocMusicViewHolder(@NonNull View itemView) {
            super(itemView);

            container = itemView;
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_sub_title = itemView.findViewById(R.id.tv_sub_title);
            tv_more = itemView.findViewById(R.id.tv_more);
            iv_more = itemView.findViewById(R.id.iv_more);
        }
    }
}
