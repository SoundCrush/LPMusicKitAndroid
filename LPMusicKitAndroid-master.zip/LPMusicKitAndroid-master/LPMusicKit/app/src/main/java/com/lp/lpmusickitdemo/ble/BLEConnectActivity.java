package com.lp.lpmusickitdemo.ble;

import android.os.Bundle;
import android.view.KeyEvent;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;

public class BLEConnectActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        setContentView(R.layout.ble_connect_activity);

        FragBLEDeviceList vfrag = new FragBLEDeviceList();

        FragUtil.replaceFrag(BLEConnectActivity.this, R.id.vfrag, vfrag, true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode != KeyEvent.KEYCODE_BACK) {
            return super.onKeyDown(keyCode, event);
        }

        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {

            Fragment vfrag = getSupportFragmentManager().findFragmentById(R.id.vfrag);
            if (vfrag instanceof FragBase) {
                ((FragBase) vfrag).onBack();
                return true;
            }
        }

        return false;
    }
}
