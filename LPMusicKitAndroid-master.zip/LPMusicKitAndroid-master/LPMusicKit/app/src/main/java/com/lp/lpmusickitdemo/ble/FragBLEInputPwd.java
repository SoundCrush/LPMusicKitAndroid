package com.lp.lpmusickitdemo.ble;

import android.net.wifi.WifiInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lp.ble.entity.LPBluetoothDevice;
import com.lp.ble.manager.ApItem;
import com.lp.ble.manager.LPBLEAPListListener;
import com.lp.ble.manager.LPBLEManager;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.util.ToolsUtil;

import java.util.ArrayList;
import java.util.List;

public class FragBLEInputPwd extends FragBase {

    private static final String TAG = "FragBLEInputPwd";

    TextView tv_wifi;
    EditText et_pwd;
    Button btn_connect;

    RecyclerView recyclerview;
    BLEAPListAdapter adapter;

    private ApItem apItem;

    private String curWifiSSID = null;

    private Handler refreshHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
        }
    };

    private LPBluetoothDevice bluetoothDevice;

    public void setBluetoothDevice(LPBluetoothDevice bluetoothDevice) {
        this.bluetoothDevice = bluetoothDevice;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_ble_input_pwd, null);

        recyclerview = cview.findViewById(R.id.recyclerview);
        tv_wifi = cview.findViewById(R.id.tv_wifi);
        et_pwd = cview.findViewById(R.id.et_pwd);
        btn_connect = cview.findViewById(R.id.btn_connect);

        WifiInfo wi = ToolsUtil.getCurrentWifiInfo();
        if (wi != null) {
            curWifiSSID = ToolsUtil.makeSSIDNoneQuoted(wi.getSSID());
        }

        if (curWifiSSID != null) {
            tv_wifi.setText("Current WiFi: " + curWifiSSID);
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        if (bluetoothDevice.match()) {
            btn_connect.setEnabled(false);
        } else
            btn_connect.setEnabled(true);

        adapter = new BLEAPListAdapter(getActivity());

        adapter.setItemClickListener(new BLEAPListAdapter.OnAPItemClickListener() {
            @Override
            public void onItemClick(ApItem bleapInfo, int pos) {

                btn_connect.setEnabled(true);
                apItem = bleapInfo;

                curWifiSSID = bleapInfo.getDisplaySSID();

                tv_wifi.setText("Current WiFi: " + curWifiSSID);
            }
        });

        recyclerview.setAdapter(adapter);

        btn_connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String password = et_pwd.getText().toString();

                if (apItem == null && !bluetoothDevice.match()) {
                    apItem = new ApItem();
                    apItem.setSsid(ToolsUtil.makeSSIDNoneQuoted(ToolsUtil.getCurrentWifiInfo().getSSID()));
                    apItem.setDisplaySSID(ToolsUtil.makeSSIDNoneQuoted(apItem.getSsid()));
                }

                FragBLEDeviceConnecting vfrag = new FragBLEDeviceConnecting();
                vfrag.setBluetoothDevice(bluetoothDevice);
                vfrag.setConnectInfo(apItem, password);

                FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);
            }
        });
        return cview;
    }

    @Override
    public void onBack() {
        super.onBack();
    }

    @Override
    public void onResume() {
        super.onResume();

        getApList();
    }

    private void getApList() {

        LPBLEManager.getInstance().getWLANList(new LPBLEAPListListener() {
            @Override
            public void onSuccess(List<ApItem> apItemList) {

                Log.i(TAG, "get WiFi list success+++");

                adapter.clear();

                ArrayList<ApItem> arrayList = new ArrayList<>();

                arrayList.addAll(apItemList);

                final ArrayList<ApItem> finalAPLIst = arrayList;

                refreshHandler.post(new Runnable() {
                    @Override
                    public void run() {

                        adapter.setDeviceList(finalAPLIst);
                        adapter.notifyDataSetChanged();
                    }
                });
            }

            @Override
            public void onFailed(Exception e) {
                Log.i(TAG, "get WiFi list failed+++:" + e.getLocalizedMessage());
            }
        });
    }
}
