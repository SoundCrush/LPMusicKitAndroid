package com.lp.lpmusickitdemo;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * @author leyunrui-wiimu
 * @version v1.0
 * @date 下午10:37 09-08-2017
 * @Description: TODO{}
 */

public class FragBase extends Fragment {

    public View cview;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onBack() {

    }
}
