package com.lp.lpmusickitdemo.device_list;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.core.app.LPDeviceManager;
import com.linkplay.core.device.LPDevice;
import com.linkplay.core.group.LPMultiroomListener;
import com.linkplay.core.group.LPMultiroomManager;
import com.linkplay.lpmdpkit.observer.LPDeviceInfoObservable;
import com.linkplay.lpmdpkit.observer.LPDeviceObserverManager;
import com.linkplay.lpmdpkit.observer.LPNotification;
import com.lp.lpmusickitdemo.CustomDeviceEventItem;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.UIApplication;
import com.lp.lpmusickitdemo.ble.BLEConnectActivity;
import com.lp.lpmusickitdemo.musicsource.FragSourceMain;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/02 19:58
 * @Description: TODO{}
 */
public class FragDeviceList extends FragBase implements LPDeviceInfoObservable {

    private static final String TAG = "FragDeviceList";

    Button btn_add_device, btn_multiroom;

    RecyclerView recyclerview;

    LPDevicesAdapter adapter = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_device_list, null);

        btn_multiroom = cview.findViewById(R.id.btn_multiroom);
        btn_add_device = cview.findViewById(R.id.btn_add_device);
        recyclerview = cview.findViewById(R.id.recyclerview);

        btn_multiroom.setEnabled(false);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        adapter = new LPDevicesAdapter(getActivity());
        adapter.setOnItemClickListener(new LPDevicesAdapter.IOnItemClickListener() {
            @Override
            public void onItemClick(int pos) {

                UIApplication.currDevice = adapter.getCurrList().get(pos);

                FragSourceMain fragSourceMain = new FragSourceMain();

                FragUtil.replaceFrag(getActivity(), R.id.vfrag, fragSourceMain, true);

            }
        });

        recyclerview.setAdapter(adapter);

        btn_multiroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //test multiroom code
                List<LPDevice> list = LPDeviceManager.getInstance().getDevices();

                LPMultiroomManager.getInstance().deviceMultiroomWithDeviceList(list,
                        new LPMultiroomListener() {
                            @Override
                            public void success(String result) {

                                refreshList();

                                Log.i(TAG, result);
                            }

                            @Override
                            public void failed(Exception e) {

                                Log.i(TAG, e.getLocalizedMessage());
                            }
                        });
            }
        });

        btn_add_device.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), BLEConnectActivity.class);
                startActivity(intent);
            }
        });

        return cview;
    }


    @Override
    public void onResume() {
        super.onResume();

        EventBus.getDefault().register(this);

        LPDeviceObserverManager.getInstance().register(this);

        refreshList();

        getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


    }

    @Override
    public void onPause() {
        super.onPause();

        EventBus.getDefault().unregister(this);

        LPDeviceObserverManager.getInstance().unregister(this);

        getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void refreshList() {

        List<LPDevice> deviceList = LPDeviceManager.getInstance().getMasterDevices();

        if (deviceList == null || deviceList.size() == 1)
            btn_multiroom.setEnabled(false);
        else
            btn_multiroom.setEnabled(true);

        adapter.setCurrList(deviceList);
        adapter.notifyDataSetChanged();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCustomDeviceEventMessage(CustomDeviceEventItem message) {

        refreshList();
    }

    @Override
    public void updateDeviceInfo(LPNotification notification) {

        Log.i(TAG, "Update device info: " + notification.getType());
    }

    @Override
    public void onBack() {
        super.onBack();

        if (getActivity() != null) {
            getActivity().finish();
        }
    }
}
