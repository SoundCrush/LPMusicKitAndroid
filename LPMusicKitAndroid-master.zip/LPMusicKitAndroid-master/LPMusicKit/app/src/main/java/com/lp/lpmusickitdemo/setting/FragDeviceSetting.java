package com.lp.lpmusickitdemo.setting;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.core.device.LPDeviceSettingsListener;
import com.linkplay.core.listener.LPDevicePlayerListener;
import com.linkplay.core.status.LPPlayChannel;
import com.linkplay.lpmdpkit.bean.LPPlayHeader;
import com.linkplay.lpmdpkit.observer.LPDeviceInfoObservable;
import com.linkplay.lpmdpkit.observer.LPDeviceObserverManager;
import com.linkplay.lpmdpkit.observer.LPNotification;
import com.linkplay.lpmdpkit.observer.LPNotificationType;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.UIApplication;
import com.lp.lpmusickitdemo.eq_mcu.FragEQMCU;
import com.lp.lpmusickitdemo.util.ToolsUtil;

import java.util.ArrayList;
import java.util.List;

public class FragDeviceSetting extends FragBase implements LPDeviceInfoObservable {

    private static final String TAG = "FragDeviceSetting";

    Handler uihd = new Handler();
    private RecyclerView recyclerView;

    List<DeviceSettingItem> currList = new ArrayList<>();
    private DeviceSettingAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_device_setting, null);

        recyclerView = cview.findViewById(R.id.recyclerview);

        adapter = new DeviceSettingAdapter(getActivity());
        initItems();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        adapter.setCurrList(currList);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new DeviceSettingAdapter.IOnItemClickImpl() {
            @Override
            public void onBtnClick(final DeviceSettingItem item) {

                switch (item.type) {
                    case eq_http: {
                        break;
                    }
                    case channel: {

                        LPPlayChannel channel = null;

                        if (item.strValue.contains(LPPlayChannel.LP_CHANNEL_STEREO.toString()))
                            channel = LPPlayChannel.LP_CHANNEL_LEFT;
                        else if (item.strValue.contains(LPPlayChannel.LP_CHANNEL_LEFT.toString()))
                            channel = LPPlayChannel.LP_CHANNEL_RIGHT;
                        else if (item.strValue.contains(LPPlayChannel.LP_CHANNEL_RIGHT.toString()))
                            channel = LPPlayChannel.LP_CHANNEL_STEREO;

                        final LPPlayChannel finalChannel = channel;
                        UIApplication.currDevice.getPlayer().setChannel(channel.getStatus(), new LPDevicePlayerListener() {
                            @Override
                            public void onSuccess(String result) {

                                Log.i(TAG, "setChannel success: " + finalChannel);

                                uihd.post(new Runnable() {
                                    @Override
                                    public void run() {

                                        DeviceSettingItem item1 = adapter.getItem(DeviceSettingItem.ENUM_TYPE.channel);
                                        if (item1 != null) {
                                            item1.strValue = finalChannel.toString();
                                            adapter.notifyDataSetChanged();
                                        }
                                    }
                                });
                            }

                            @Override
                            public void onFailure(Exception e) {

                                Log.i(TAG, "setChannel failed: " + e.getLocalizedMessage());
                            }
                        });

                        break;
                    }

                    case ssid_hide: {

                        boolean bHide = false;

                        bHide = !item.strValue.contains("false");

                        bHide = !bHide;

                        UIApplication.currDevice.getDeviceSettings().hideSSID(bHide, new LPDeviceSettingsListener() {
                            @Override
                            public void success(String result) {

                                final boolean isHide = UIApplication.currDevice.getDeviceStatus().isHideSSID();
                                Log.i(TAG, "hide success: " + isHide);
                                uihd.post(new Runnable() {
                                    @Override
                                    public void run() {


                                        DeviceSettingItem item1 = adapter.getItem(DeviceSettingItem.ENUM_TYPE.ssid_hide);
                                        if (item1 != null) {
                                            item1.strValue = isHide + "";
                                            adapter.notifyDataSetChanged();
                                        }
                                    }
                                });
                            }

                            @Override
                            public void failure(Exception e) {

                                Log.i(TAG, "hide failed: " + e.getLocalizedMessage());
                            }
                        });

                        break;
                    }
                    case eq_mcu: {

                        FragEQMCU vfrag = new FragEQMCU();
                        FragUtil.replaceFrag(getActivity(), R.id.vfrag, vfrag, true);

                        break;
                    }
                    case spotify_account:{
                        updateSpotifyAccountItem();
                        break;
                    }

                    case reset_device:{

                        showDialog("restore device...");
                        UIApplication.currDevice.getDeviceSettings().resetDeviceWithHandler(new LPDeviceSettingsListener() {
                            @Override
                            public void success(String result) {
                                dismissDialog();
                                Log.i(TAG, "reset device success: " + result);
                            }

                            @Override
                            public void failure(Exception e) {
                                dismissDialog();
                                Log.i(TAG, "reset device failed: " + e.getLocalizedMessage());
                            }
                        });
                        break;
                    }

                    case none:
                    default:
                        break;
                }
            }
        });

        return cview;
    }

    private void updateSpotifyAccountItem(){

        boolean bFree = ToolsUtil.isFreeSpotifyAccount(UIApplication.currDevice);

        uihd.post(new Runnable() {
            @Override
            public void run() {

                DeviceSettingItem item1 = adapter.getItem(DeviceSettingItem.ENUM_TYPE.spotify_account);
                if (item1 != null) {
                    item1.strValue = (bFree ? "Free Account" : "Private Account");
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    private boolean isFreeSpotifyAccount(){

        String mediaType = UIApplication.currDevice.getMediaInfo().getMediaType();
        if(!TextUtils.equals(mediaType, LPPlayHeader.LPPlayMediaType.LP_SPOTIFY))
            return false;

        int skiplimit = UIApplication.currDevice.getMediaInfo().getSkiplimit();
        if(skiplimit == 1)
            return true;

        return false;
    }

    private ProgressDialog progressDialog = null;

    private void showDialog(String message) {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }


        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setTitle(message);
        progressDialog.show();
    }

    private void dismissDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }

    }

    private void initItems() {

        if (currList != null)
            currList.clear();

        DeviceSettingItem item = new DeviceSettingItem();
        item.type = DeviceSettingItem.ENUM_TYPE.channel;
        item.strBtnText = "CHANNEL";
        item.strLabel = "Current Channel:";
        item.strValue = UIApplication.currDevice.getDeviceInfo().getPlayChannel().toString();
        currList.add(item);

        item = new DeviceSettingItem();
        item.type = DeviceSettingItem.ENUM_TYPE.ssid_hide;
        item.strBtnText = "SSID";
        item.strLabel = "SSID Hide:";
        item.strValue = UIApplication.currDevice.getDeviceStatus().isHideSSID() + "";
        currList.add(item);

        item = new DeviceSettingItem();
        item.type = DeviceSettingItem.ENUM_TYPE.eq_http;
        item.strBtnText = "EQ HTTP";
        item.strLabel = "EQ Status:";
        item.strValue = "";
        currList.add(item);

        item = new DeviceSettingItem();
        item.type = DeviceSettingItem.ENUM_TYPE.eq_mcu;
        item.strBtnText = "EQ MCU";
        item.strLabel = "";
        item.strValue = "";
        currList.add(item);

        item = new DeviceSettingItem();
        item.type = DeviceSettingItem.ENUM_TYPE.spotify_account;
        item.strBtnText = "Spotify Account";
        item.strLabel = "";
        item.strValue = "";
        currList.add(item);

        item = new DeviceSettingItem();
        item.type = DeviceSettingItem.ENUM_TYPE.reset_device;
        item.strBtnText = "Reset Device";
        item.strLabel = "";
        item.strValue = "";
        currList.add(item);
    }

    @Override
    public void onResume() {
        super.onResume();

        LPDeviceObserverManager.getInstance().register(this);


        getEQ();

        updateSpotifyAccountItem();
    }

    @Override
    public void onPause() {
        super.onPause();

        LPDeviceObserverManager.getInstance().unregister(this);
    }

    @Override
    public void onBack() {
        super.onBack();
        FragUtil.popBack(getActivity());
    }

    private void getEQ() {

        UIApplication.currDevice.getDeviceSettings().getSupportEQAndValues(new LPDeviceSettingsListener() {
            @Override
            public void success(final String s) {

                Log.i(TAG, "getSupportEQAndValues success: " + s);

                uihd.post(new Runnable() {
                    @Override
                    public void run() {

                        DeviceSettingItem item = adapter.getItem(DeviceSettingItem.ENUM_TYPE.eq_http);
                        if (item != null) {
                            item.strValue = s;
                            adapter.notifyDataSetChanged();
                        }
                    }
                });
            }

            @Override
            public void failure(Exception e) {
                Log.i(TAG, "getSupportEQAndValues failure: " + e.getLocalizedMessage());
            }
        });
    }

    @Override
    public void updateDeviceInfo(LPNotification lpNotification) {

        if (lpNotification.getUuid().equals(UIApplication.currDevice.getUpnpUUID())) {

            if (lpNotification.getType().equals(LPNotificationType.CHANNEL_CHANGED)) {

                updateChannel();
            }
        }
    }

    //更新频道
    private void updateChannel() {

        uihd.post(new Runnable() {
            @Override
            public void run() {

                LPPlayChannel playChannel = UIApplication.currDevice.getDeviceInfo().getPlayChannel();

                DeviceSettingItem item = adapter.getItem(DeviceSettingItem.ENUM_TYPE.channel);

                if (item != null) {

                    if (playChannel == LPPlayChannel.LP_CHANNEL_LEFT) {
                        Log.i(TAG, "LP_CHANNEL_LEFT");
                        item.strValue = "LP_CHANNEL_LEFT";
                    } else if (playChannel == LPPlayChannel.LP_CHANNEL_RIGHT) {
                        Log.i(TAG, "LP_CHANNEL_RIGHT");
                        item.strValue = "LP_CHANNEL_RIGHT";
                    } else if (playChannel == LPPlayChannel.LP_CHANNEL_STEREO) {
                        Log.i(TAG, "LP_CHANNEL_STEREO");
                        item.strValue = "LP_CHANNEL_STEREO";
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

}
