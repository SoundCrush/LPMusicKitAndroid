package com.lp.lpmusickitdemo;

import java.io.Serializable;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/31 18:02
 * @Description: TODO{}
 */
public class CustomDeviceEventItem implements Serializable {


}
