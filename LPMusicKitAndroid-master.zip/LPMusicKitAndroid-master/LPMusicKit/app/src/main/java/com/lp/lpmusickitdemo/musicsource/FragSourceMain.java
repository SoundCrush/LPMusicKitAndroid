package com.lp.lpmusickitdemo.musicsource;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.core.device.LPDeviceSettingsListener;
import com.linkplay.medialib.LPMSLibraryManager;
import com.lp.lpmusickitdemo.CustomDeviceEventItem;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.UIApplication;
import com.lp.lpmusickitdemo.musicsource.loc_music.FragLocMusic;
import com.lp.lpmusickitdemo.setting.FragDeviceSetting;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/08/06 11:34
 * @Description: TODO{}
 */
public class FragSourceMain extends FragBase {

    RecyclerView recyclerview;
    SourceMainAdapter adapter = null;
    private boolean bShowUSB = false;//是否支持USB

    private Handler uihd = new Handler();

    @SuppressLint("WrongConstant")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_source_main, null);

        recyclerview = cview.findViewById(R.id.recyclerview);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        adapter = new SourceMainAdapter(getActivity());

        adapter.setOnItemClickListener(new SourceMainAdapter.IOnItemClickListener() {
            @Override
            public void onItemClick(int pos) {

                SourceMainAdapter.SourceItem item = adapter.getCurrList().get(pos);

                if (item.key == SourceMainAdapter.SourceItem.KEY.LOC_MUSIC) {

                    FragLocMusic vfrag = new FragLocMusic();
                    FragUtil.replaceFrag(getActivity(), R.id.vfrag, vfrag, true);

                } else if (item.key == SourceMainAdapter.SourceItem.KEY.PLAY_CONTROL) {

                    Intent intent = new Intent(getActivity(), PlayControlActivity.class);
                    startActivity(intent);
                } else if(item.key == SourceMainAdapter.SourceItem.KEY.DEVICE_SETTING){

                    FragDeviceSetting vfrag = new FragDeviceSetting();
                    FragUtil.replaceFrag(getActivity(), R.id.vfrag, vfrag, true);
                }
            }
        });

        recyclerview.setAdapter(adapter);

        return cview;
    }

    @Override
    public void onResume() {
        super.onResume();

        getUSBStatus();

        refrshList();
    }

    private void getUSBStatus() {

        bShowUSB = false;

        UIApplication.currDevice.getDeviceSettings().getUSBDiskStatus(
                new LPDeviceSettingsListener() {
                    @Override
                    public void success(String result) {
                        bShowUSB = result.equals("1");

                        uihd.post(new Runnable() {
                            @Override
                            public void run() {

                                refrshList();
                            }
                        });
                    }

                    @Override
                    public void failure(Exception e) {

                    }
                });
    }

    private List<SourceMainAdapter.SourceItem> getSources() {

        List<SourceMainAdapter.SourceItem> currList = new ArrayList<>();

        String strMyMusic = "My Music(" + LPMSLibraryManager.getInstance(UIApplication.instance).getCount() + ")";

        int nasCount = 0;//LPNASManager.getInstance().getCount();
        String strNAS = "NAS" + (nasCount > 0 ? ("(" + nasCount + ")") : "");
        String strAMAZON = "Amazon";
        String playControl = "PlayControl";
        String alarm = "Alarm";
        String preset = "Preset";
        String tunein = "TuneIn";
        String tidal = "Tidal";

        String strSwitchMode = "Switch Mode";

        String strDeviceSetting = "Device Setting";

        currList.add(new SourceMainAdapter.SourceItem(strMyMusic, SourceMainAdapter.SourceItem.KEY.LOC_MUSIC));
        currList.add(new SourceMainAdapter.SourceItem(playControl, SourceMainAdapter.SourceItem.KEY.PLAY_CONTROL));
//        currList.add(new SourceMainAdapter.SourceItem(strNAS, SourceMainAdapter.SourceItem.KEY.NAS));
//        currList.add(new SourceMainAdapter.SourceItem(alarm, SourceMainAdapter.SourceItem.KEY.ALARM));
//        currList.add(new SourceMainAdapter.SourceItem(preset, SourceMainAdapter.SourceItem.KEY.PRESET));
//        currList.add(new SourceMainAdapter.SourceItem(tunein, SourceMainAdapter.SourceItem.KEY.TUNEIN));
//        currList.add(new SourceMainAdapter.SourceItem(strAMAZON, SourceMainAdapter.SourceItem.KEY.AMAZON_MUSIC));
//        currList.add(new SourceMainAdapter.SourceItem(tidal, SourceMainAdapter.SourceItem.KEY.TIDAL));

        if (bShowUSB) {
            String strUSB = "USBDisk";
            currList.add(new SourceMainAdapter.SourceItem(strUSB, SourceMainAdapter.SourceItem.KEY.USBDISK));
        }

        currList.add(new SourceMainAdapter.SourceItem(strSwitchMode, SourceMainAdapter.SourceItem.KEY.SWITCH_MODE));

        currList.add(new SourceMainAdapter.SourceItem(strDeviceSetting, SourceMainAdapter.SourceItem.KEY.DEVICE_SETTING));

        return currList;
    }


    @Override
    public void onBack() {
        super.onBack();

        FragUtil.popBack(getActivity());
    }

    private void refrshList() {

        adapter.setCurrList(getSources());
        adapter.notifyDataSetChanged();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCustomDeviceEventMessage(CustomDeviceEventItem message) {
        refrshList();
    }
}
