package com.lp.lpmusickitdemo.util.glide;

import android.graphics.Bitmap;

/**
 * @author leyunrui-wiimu
 * @version v1.0
 * @date 上午10:58 18-07-2017
 * @Description: TODO{}
 */

public interface BitmapLoadingListener {

    void onSuccess(Bitmap bitmap);
    void onError();
}
