package com.lp.lpmusickitdemo.ble;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.R;


public class FragBLEConnectSuccess extends FragBase {

    Button btn_success;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_ble_connect_success, null);

        btn_success = cview.findViewById(R.id.btn_success);

        btn_success.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().finish();
            }
        });

        return cview;
    }
}
