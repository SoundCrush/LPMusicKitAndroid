package com.lp.lpmusickitdemo;

import android.app.Application;

import com.linkplay.core.app.LPDeviceManager;
import com.linkplay.core.device.LPDevice;
import com.lp.ble.manager.LPBLEManager;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/02 19:53
 * @Description: TODO{}
 */
public class UIApplication extends Application {

    public static LPDevice currDevice;
    public static UIApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();

        instance = this;

        LPBLEManager.getInstance().init(this);

        new CustomDeviceManager(this);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();

        LPDeviceManager.getInstance().stop();
        LPDeviceManager.getInstance().removeObserver();
    }
}
