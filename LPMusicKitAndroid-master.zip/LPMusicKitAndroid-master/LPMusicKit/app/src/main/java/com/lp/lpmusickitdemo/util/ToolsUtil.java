package com.lp.lpmusickitdemo.util;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.core.graphics.drawable.DrawableCompat;

import com.linkplay.core.device.LPDevice;
import com.linkplay.lpmdpkit.bean.LPPlayHeader;
import com.lp.lpmusickitdemo.UIApplication;

import java.text.DecimalFormat;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/08/01 09:38
 * @Description: TODO{}
 */
public class ToolsUtil {

    public static void showAuthToast(final Context context, final String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast authToast = Toast.makeText(context, message, Toast.LENGTH_SHORT);
                authToast.show();
            }
        });
    }

    public static String ConvertFavorite(int followCount) {
        double f = followCount / 1000.0;
        DecimalFormat df = new DecimalFormat("#0.0");
        return df.format(f) + "K";
    }

    public static Drawable getTintListDrawable(Drawable drawable, ColorStateList colorStateList) {

        if (drawable == null)
            return null;

        Drawable backDraw = getWrapDrawable(drawable);
        if (backDraw == null)
            return null;

        DrawableCompat.setTintList(backDraw, colorStateList);

        return backDraw;
    }

    public static Drawable getWrapDrawable(Drawable drawable) {

        if (drawable == null)
            return null;

        Drawable.ConstantState state = drawable.getConstantState();
        Drawable backDraw = DrawableCompat.wrap(state == null ? drawable : state.newDrawable()).mutate();
        if (backDraw == null)
            return drawable;

        backDraw.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());

        return backDraw;
    }

    @Deprecated
    public static String makeIPV4IP(Context context) {
        WifiManager wifiManager = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();

        int ipAddress = wifiInfo.getIpAddress();
        String tmpIP = String.format("%d.%d.%d.%d", (ipAddress & 0xff),
                (ipAddress >> 8 & 0xff), (ipAddress >> 16 & 0xff),
                (ipAddress >> 24 & 0xff));
        return tmpIP;
    }

    /***
     *
     * @param
     */
    public static String getTimeTick(long timetick) {
        long chour = timetick / 3600;
        long cmin = (timetick - chour * 3600) / 60;
        long csec = (timetick - chour * 3600 - cmin * 60);
        return String.format("%02d:%02d", cmin + chour * 60, csec);
    }


    public static WifiInfo getCurrentWifiInfo() {
        WifiManager mWifi = (WifiManager) UIApplication.instance
                .getSystemService(Context.WIFI_SERVICE);
//		if (!mWifi.isWifiEnabled()) {
//			// mWifi.setWifiEnabled(true);
//			mWifi.setWifiEnabled(false);
//		}

        WifiInfo wifiInfo = mWifi.getConnectionInfo();

        return wifiInfo;

    }

    public static String getWiFiSSID() {
        WifiInfo wi = getCurrentWifiInfo();
        String ssid = "";
        String tmpWIFISSID = "";
        if (wi != null) {
            ssid = wi.getSSID();
        }
        if (ssid != null) {
            tmpWIFISSID = makeSSIDNoneQuoted(ssid);
        }
        return tmpWIFISSID;
    }

    // 移除 \" 双引号
    //譬如ssid中间带有\"的不可以替换，只可以替换两头的\"
    public static String makeSSIDNoneQuoted(String ssid) {
        if (ssid == null)
            return "";

        if (ssid.startsWith("\""))
            ssid = ssid.substring(1).trim();

        if (ssid.endsWith("\""))
            ssid = ssid.substring(0, (ssid.length() - 1)).trim();

        return ssid;
    }

    public static String getDateTime(String datetime) {
        String time = "";
        if (!TextUtils.isEmpty(datetime)) {
            time = datetime;
        }
        if (datetime.contains("T")) {
            time = datetime.replace("T", " ");
        }
        return time;
    }

    /**
     * @param duration
     * @return
     */
    public static String secondToTime(String duration) {
        if (TextUtils.isEmpty(duration)) {
            return "";
        } else {
            long second = 0;
            try {
                second = Long.parseLong(duration);
                long hours = second / 3600;//转换小时数
                second = second % 3600;//剩余秒数
                long minutes = second / 60;//转换分钟
                second = second % 60;//剩余秒数
                String hours_str = hours + "";
                String minutes_str = minutes + "";
                String second_str = second + "";
                if (hours < 10) {
                    hours_str = "0" + hours;
                }
                if (minutes < 10) {
                    minutes_str = "0" + minutes;
                }
                if (second < 10) {
                    second_str = "0" + second;
                }
                return hours_str + ":" + minutes_str + ":" + second_str;
            } catch (NumberFormatException e) {
                e.printStackTrace();
                return "";
            }

        }
    }

    /**
     * is free spotify
     * @param lpDevice
     * @return
     */
    public static boolean isFreeSpotifyAccount(LPDevice lpDevice) {

        if (lpDevice == null)
            return false;

        String mediaType = lpDevice.getMediaInfo().getMediaType();
        if (!TextUtils.equals(mediaType, LPPlayHeader.LPPlayMediaType.LP_SPOTIFY))
            return false;

        int skiplimit = UIApplication.currDevice.getMediaInfo().getSkiplimit();
        if (skiplimit == 0)
            return false;

        return true;
    }
}
