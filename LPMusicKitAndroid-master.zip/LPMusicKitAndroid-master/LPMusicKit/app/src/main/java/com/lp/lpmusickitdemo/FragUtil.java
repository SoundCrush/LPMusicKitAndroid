package com.lp.lpmusickitdemo;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class FragUtil {

    public static void replaceFrag(FragmentActivity fragAct, int fragId,
                                   Fragment vfrag, boolean needBack) {
        if (fragAct == null) return;
        FragmentManager fm = fragAct.getSupportFragmentManager();
        if (fm == null) return;
        FragmentTransaction ft = fm.beginTransaction();
        if (ft == null) return;
        ft.replace(fragId, vfrag);
        // todo modify back --key
        if (needBack) {
            ft.addToBackStack(null);
        }
        ft.commitAllowingStateLoss();
    }


    public static void addFrag(FragmentActivity fragAct, int fragId,
                               Fragment vfrag, boolean needBack) {
        if (fragAct == null) return;
        FragmentManager fm = fragAct.getSupportFragmentManager();
        if (fm == null) return;
        FragmentTransaction ft = fm.beginTransaction();
        if (ft == null) return;
        ft.add(fragId, vfrag);
        // todo modify back --key
        if (needBack) {
            ft.addToBackStack(null);
        }
        ft.commitAllowingStateLoss();
    }

    public static void popBack(FragmentActivity fragAct) {
        if (fragAct == null) return;
        if (fragAct.getSupportFragmentManager() == null) return;
        fragAct.getSupportFragmentManager().popBackStack();
    }


}
