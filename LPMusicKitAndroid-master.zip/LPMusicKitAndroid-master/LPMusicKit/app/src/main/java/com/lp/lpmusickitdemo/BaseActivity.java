package com.lp.lpmusickitdemo;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.lp.lpmusickitdemo.device_list.FragDeviceList;


/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/31 19:12
 * @Description: TODO{}
 */
public class BaseActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        setContentView(R.layout.base_activity);

        FragDeviceList vfrag = new FragDeviceList();

        FragUtil.replaceFrag(BaseActivity.this, R.id.vfrag, vfrag, true);
    }

    @Override
    protected void onResume() {
        super.onResume();

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    protected void onPause() {
        super.onPause();

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        //退出应用
        System.exit(0);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode != KeyEvent.KEYCODE_BACK) {
            return super.onKeyDown(keyCode, event);
        }

        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {

            Fragment vfrag = getSupportFragmentManager().findFragmentById(R.id.vfrag);
            if (vfrag instanceof FragBase) {
                ((FragBase) vfrag).onBack();
                return true;
            }
        }

        return false;
    }
}
