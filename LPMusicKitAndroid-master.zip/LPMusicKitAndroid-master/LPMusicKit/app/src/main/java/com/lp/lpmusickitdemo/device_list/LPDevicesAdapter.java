package com.lp.lpmusickitdemo.device_list;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.core.device.LPDevice;
import com.lp.lpmusickitdemo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/31 16:56
 * @Description: TODO{}
 */
public class LPDevicesAdapter extends RecyclerView.Adapter<LPDevicesAdapter.LPDeviceViewHolder> {

    List<LPDevice> currList = new ArrayList<>();
    private Context mContext;

    public LPDevicesAdapter(Context context) {

        this.mContext = context;
    }

    public void setCurrList(List<LPDevice> list) {
        currList = list;
    }

    public List<LPDevice> getCurrList() {
        return currList;
    }

    @NonNull
    @Override
    public LPDeviceViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int pos) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item_lpdevice, null);
        LPDeviceViewHolder holder = new LPDeviceViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull LPDeviceViewHolder lpDeviceViewHolder, final int pos) {

        LPDevice item = currList.get(pos);

        lpDeviceViewHolder.dev_name.setText(item.getDeviceStatus().getFriendlyName());

        lpDeviceViewHolder.container.setBackground(mContext.getDrawable(R.drawable.selector_item_bg));

        lpDeviceViewHolder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (listener != null)
                    listener.onItemClick(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return currList == null ? 0 : currList.size();
    }

    private IOnItemClickListener listener;

    public void setOnItemClickListener(IOnItemClickListener listener) {
        this.listener = listener;
    }

    public interface IOnItemClickListener {
        void onItemClick(int pos);
    }

    public static class LPDeviceViewHolder extends RecyclerView.ViewHolder {

        public View container;
        public TextView dev_name;

        public LPDeviceViewHolder(@NonNull View itemView) {
            super(itemView);

            this.container = itemView;
            dev_name = itemView.findViewById(R.id.dev_name);
        }
    }
}
