package com.lp.lpmusickitdemo.ble;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.R;

public class FragBLEConnectFailed extends FragBase {

    Button btn_failed;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_ble_connect_failed, null);

        btn_failed = cview.findViewById(R.id.btn_failed);

        btn_failed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().finish();
            }
        });

        return cview;
    }
}
