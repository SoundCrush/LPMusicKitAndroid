package com.lp.lpmusickitdemo.ble;

import android.Manifest;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lp.ble.entity.LPBluetoothDevice;
import com.lp.ble.manager.LPBLEManager;
import com.lp.ble.manager.LPBLEScanListener;
import com.lp.ble.manager.LPConnectBLEListener;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class FragBLEDeviceList extends FragBase {

    private static final String TAG = "FragBLEDeviceList";

    private BluetoothAdapter mBluetoothAdapter;
    RecyclerView recyclerview;
    private static final int REQUEST_CODE_ACCESS_COARSE_LOCATION = 1;
    private boolean scanning = false;

    private ConcurrentHashMap<String, LPBluetoothDevice> deviceMap = new ConcurrentHashMap<>();

    BLEDeviceListAdapter adapter;

    LPBluetoothDevice lpBluetoothDevice;

    private Handler refreshHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_ble_device_list, null);

        recyclerview = cview.findViewById(R.id.recyclerview);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        adapter = new BLEDeviceListAdapter(getActivity());

        adapter.setItemClickListener(new BLEDeviceListAdapter.OnBleItemClickListener() {
            @Override
            public void onItemClick(final LPBluetoothDevice bluetoothDevice, int pos) {

                lpBluetoothDevice = bluetoothDevice;

                LPBLEManager.getInstance().connectBLE(bluetoothDevice, bleListener);
            }
        });

        recyclerview.setAdapter(adapter);

        LPBLEManager.getInstance().stopScan();
        startScanBle();

        return cview;
    }

    LPConnectBLEListener bleListener = new LPConnectBLEListener() {
        @Override
        public void onFailed(int i, String s) {
            Log.i(TAG, "connectBLE onFailed");
            dismissDialog();
        }

        @Override
        public void onStartConnect() {
            Log.i(TAG, "connectBLE onStartConnect");

            showDialog("start connecting " + lpBluetoothDevice.getBluetoothDevice().getName());
        }

        @Override
        public void onConnectFail(Exception e) {
            Log.i(TAG, "connectBLE onConnectFail");
            dismissDialog();
        }

        @Override
        public void onConnectSuccess(BluetoothGatt bluetoothGatt, int i) {

            Log.i(TAG, "connectBLE onConnectSuccess");

            dismissDialog();

            LPBLEManager.getInstance().stopScan();
            connectBLE(lpBluetoothDevice);
        }

        @Override
        public void onDisConnected(boolean b, BluetoothGatt bluetoothGatt, int i) {

            dismissDialog();

            Log.i(TAG, "connectBLE onDisConnected");
        }
    };

    private void connectBLE(LPBluetoothDevice bluetoothDevice) {

        try {
            Thread.sleep(500);

            FragBLEInputPwd vfrag = new FragBLEInputPwd();
            vfrag.setBluetoothDevice(bluetoothDevice);
            FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private boolean searchOnce = false;

    @Override
    public void onResume() {
        super.onResume();

        searchOnce = false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            //OS 7.1 bug，if not open GPS，BLE can not search any device
            getGPS(getActivity());
        } else {
            requestBLEPermisson();
        }
    }

    private ProgressDialog progressDialog = null;

    private void showDialog(String message) {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }


        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setTitle(message);
        progressDialog.show();
    }

    private void dismissDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }

    }

    /**
     * start scan ble
     */
    public void startScanBle() {

        if (deviceMap != null)
            deviceMap.clear();

        if (adapter != null)
            adapter.clear();

        LPBLEManager.getInstance().startScan(lpbleScanListener);
    }

    LPBLEScanListener lpbleScanListener = new LPBLEScanListener() {

        @Override
        public void LPBLEScanFinish() {

            scanning = false;
        }

        @Override
        public void LPBLEScanResult(LPBluetoothDevice device) {

            ArrayList<LPBluetoothDevice> tmpDeviceList = adapter.getDeviceList();

            if (tmpDeviceList == null)
                tmpDeviceList = new ArrayList<>();

            deviceMap.put(device.getIdentification(), device);
            //replace old ble device

            boolean hasBluetooth = false;
            final int size = tmpDeviceList.size();
            for (int i = 0; i < size; i++) {

                LPBluetoothDevice tmpLPBluetoothDevice = tmpDeviceList.get(i);
                if (tmpLPBluetoothDevice.getIdentification().contains(device.getIdentification())) {
                    hasBluetooth = true;
                    tmpDeviceList.set(i, device);
                    break;
                }
            }

            if (!hasBluetooth) {
                tmpDeviceList.add(device);
            }

            final ArrayList<LPBluetoothDevice> finalTmpDeviceList = tmpDeviceList;
            refreshHandler.post(new Runnable() {
                @Override
                public void run() {
                    adapter.setDeviceList(finalTmpDeviceList);
                    adapter.notifyDataSetChanged();
                }
            });
        }

        @Override
        public void LPBLEScanFailed(int error) {
        }
    };

    /**
     * get GPS on/off, and search device
     */
    private void getGPS(final Context context) {
        if (getActivity() == null)
            return;

        boolean gps = isGpsEnabled(context);
        if (gps) {
            requestBLEPermisson();
        } else {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(intent);
        }
    }

    /**
     * LocationManager
     */
    public static boolean isGpsEnabled(Context context) {

        LocationManager locationManager =
                (LocationManager) context
                        .getApplicationContext()
                        .getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
            return true;
        }

        final List<String> providers = locationManager.getAllProviders();
        if (providers == null) {
            return true;
        }

        if (providers.contains(LocationManager.GPS_PROVIDER)) {

            return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        } else {
            // The OS System has not BLE Module,
            return true;
        }
    }

    /**
     * check Permission
     */
    private void requestBLEPermisson() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {//如果 API level 是大于等于 23(Android 6.0) 时
            //has permission
            if (ContextCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                        Manifest.permission.ACCESS_COARSE_LOCATION)) {
                }
                //request permissions
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                        REQUEST_CODE_ACCESS_COARSE_LOCATION);
            } else {
                if (getActivity() != null) {
                    if (searchOnce) {
                        //get bluetooth adapter
                        searchOnce = false;
                        checkBLE();
                    }
                }
            }
        } else {
            if (getActivity() != null) {
                if (searchOnce) {
                    ///get bluetooth adapter
                    searchOnce = false;
                    checkBLE();
                }
            }
        }
    }

    private void checkBLE() {
        // check this mobile has support ble, if not then exit
        if (!getActivity().getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            return;
        }

        //get bluetooth adapter form bt manager，below 5.0 not compatible
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return;
        } else {

            if (getActivity() == null)
                return;
            final BluetoothManager bluetoothManager = (BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE);
            mBluetoothAdapter = bluetoothManager.getAdapter();

            if (mBluetoothAdapter == null) {
                return;
            }
        }
        checkBTEnable();
    }

    private void checkBTEnable() {
        if (mBluetoothAdapter != null) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);
            } else {
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        LPBLEManager.getInstance().stopScan();
    }

    @Override
    public void onBack() {
        super.onBack();

        getActivity().finish();
    }
}
