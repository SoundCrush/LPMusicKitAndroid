package com.lp.lpmusickitdemo.musicsource.loc_music;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/08/21 13:29
 * @Description: TODO{}
 */
public enum  CheckItemType {

    SONGS_RADIO_TYPE,
    ARTIST_RADIO_TYPE,
    ALBUM_RADIO_TYPE,
    SONGLIST_RADIO_TYPE
}
