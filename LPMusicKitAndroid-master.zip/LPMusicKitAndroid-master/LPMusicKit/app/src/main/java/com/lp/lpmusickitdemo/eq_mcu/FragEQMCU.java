package com.lp.lpmusickitdemo.eq_mcu;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.linkplay.passthrough.LPPassthrough;
import com.linkplay.passthrough.LPPassthroughListener;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.UIApplication;

public class FragEQMCU extends FragBase implements LPPassthroughListener {

    private static final String TAG = "FragEQMCU";

    LPPassthrough presenter;

    EditText et_command;
    TextView tv_recv_msg;
    Button btn_connect, btn_send;

    StringBuffer strMsg = new StringBuffer();

    private static Handler uihd = new Handler();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_eq_mcu, null);

        et_command = cview.findViewById(R.id.et_command);
        btn_connect = cview.findViewById(R.id.btn_connect);
        btn_send = cview.findViewById(R.id.btn_send);
        tv_recv_msg = cview.findViewById(R.id.tv_recv_msg);

        btn_send.setAlpha(0.5f);
        btn_send.setEnabled(false);

        btn_connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                connect();
            }
        });

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                send();
            }
        });

        return cview;
    }

    private void connect() {

        if (UIApplication.currDevice == null)
            return;

        String ip = UIApplication.currDevice.getIp();
        if (TextUtils.isEmpty(ip))
            return;

        if (presenter == null)
            presenter = new LPPassthrough(UIApplication.currDevice, this);

        presenter.connect();
    }

    private void send() {

        strMsg = new StringBuffer();

        String command = et_command.getText().toString().trim();
        //example:EQG or auto define command
        if (presenter != null)
            presenter.write(String.format("MCU+PAS+%s&", command));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (presenter != null) {
            presenter.disConnect();
            presenter = null;
        }
    }

    @Override
    public void onBack() {
        super.onBack();

        if (presenter != null) {
            presenter.disConnect();
        }

        if (uihd != null)
            uihd.removeCallbacksAndMessages(null);

        FragUtil.popBack(getActivity());
    }

    @Override
    public void onException(Exception e, int errorCode) {

    }

    @Override
    public void connectionStateChanged(boolean isConnected) {

        if (isConnected) {
            Log.i(TAG, "connectionSuccessful");

            uihd.post(new Runnable() {
                @Override
                public void run() {

                    btn_send.setAlpha(1f);
                    btn_send.setEnabled(true);
                }
            });
        }
    }

    @Override
    public void passThroughMessageCome(String response) {

        Log.i(TAG, "receivedMessage:" + response);

        strMsg.append(response + "\n");
        uihd.post(new Runnable() {
            @Override
            public void run() {
                tv_recv_msg.setText(strMsg);
            }
        });
    }
}
