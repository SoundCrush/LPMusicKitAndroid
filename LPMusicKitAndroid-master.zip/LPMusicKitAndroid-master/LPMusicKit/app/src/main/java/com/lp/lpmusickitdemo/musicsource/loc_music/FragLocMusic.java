package com.lp.lpmusickitdemo.musicsource.loc_music;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.core.device.LPDevice;
import com.linkplay.core.listener.LPDevicePlayerListener;
import com.linkplay.core.status.LPPlayQueueType;
import com.linkplay.lpmdpkit.LPMDPKitManager;
import com.linkplay.lpmdpkit.LPPlaySourceType;
import com.linkplay.lpmdpkit.bean.LPPlayHeader;
import com.linkplay.lpmdpkit.bean.LPPlayItem;
import com.linkplay.lpmdpkit.bean.LPPlayMusicList;
import com.linkplay.lpmdpkit.observer.LPDeviceInfoObservable;
import com.linkplay.lpmdpkit.observer.LPDeviceObserverManager;
import com.linkplay.lpmdpkit.observer.LPNotification;
import com.linkplay.mediainfo.LPMediaInfo;
import com.linkplay.medialib.LPMSLibraryManager;
import com.linkplay.medialib.LPMSLibraryPlayItem;
import com.linkplay.medialib.LPSearchMediaResultListener;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.UIApplication;
import com.lp.lpmusickitdemo.musicsource.PlayControlActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/31 19:12
 * @Description: TODO{}
 */
public class FragLocMusic extends FragBase implements LPDeviceInfoObservable {

    private static final String TAG = "FragLocMusic";


    RecyclerView recyclerview;
    RadioGroup tab_group;
    RadioButton song_radio, artist_radio, album_radio, songlist_radio;

    LPDevice mLPDevice;

    LocMusicAdapter adapter;

    LPPlayHeader songsPlayHeader, artistPlayHeader, albumPlayHeader, songlistPlayHeader;

    List<LPMSLibraryPlayItem> songsList = new ArrayList<>();
    List<LPMSLibraryPlayItem> artistList = new ArrayList<>();
    List<LPMSLibraryPlayItem> albumList = new ArrayList<>();
    List<LPMSLibraryPlayItem> songlistList = new ArrayList<>();

    private static final int UPDATE_SONGS_LIST = 1;//update songlist
    private static final int BTN_PLAY_STATUS = 2;//play status
    private static final int BTN_PAUSE_STATUS = 3;//pause status
    private static final int UPDATE_ARTIST_LIST = 5;//artist
    private static final int UPDATE_ALBUM_LIST = 6;//album
    private static final int UPDATE_SONGLIST_LIST = 7;//songlist list

    Handler uihd = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            int what = msg.what;

            if (what == UPDATE_SONGS_LIST) {

                if (adapter != null) {
                    adapter.setCurrList(CheckItemType.SONGS_RADIO_TYPE, songsList);
                    adapter.notifyDataSetChanged();
                }

            } else if (what == UPDATE_ARTIST_LIST) {

                if (adapter != null) {
                    adapter.setCurrList(CheckItemType.ARTIST_RADIO_TYPE, artistList);
                    adapter.notifyDataSetChanged();
                }
            } else if (what == UPDATE_ALBUM_LIST) {
                if (adapter != null) {
                    adapter.setCurrList(CheckItemType.ALBUM_RADIO_TYPE, albumList);
                    adapter.notifyDataSetChanged();
                }
            } else if (what == UPDATE_SONGLIST_LIST) {
                if (adapter != null) {
                    adapter.setCurrList(CheckItemType.SONGLIST_RADIO_TYPE, songlistList);
                    adapter.notifyDataSetChanged();
                }
            } else if (what == BTN_PLAY_STATUS) {

            } else if (what == BTN_PAUSE_STATUS) {

            }
        }
    };

    @SuppressLint("WrongConstant")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_loc_music, null);

        recyclerview = cview.findViewById(R.id.recyclerview);
        tab_group = cview.findViewById(R.id.table_group);
        song_radio = cview.findViewById(R.id.song_radio);
        artist_radio = cview.findViewById(R.id.artist_radio);
        album_radio = cview.findViewById(R.id.album_radio);
        songlist_radio = cview.findViewById(R.id.songlist_radio);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        adapter = new LocMusicAdapter(getActivity());
        adapter.setOnItemClickListener(new LocMusicAdapter.IOnItemClickListener() {
            @Override
            public void onItemClick(CheckItemType radioType, int pos) {

                if (radioType == CheckItemType.SONGS_RADIO_TYPE) {
                    clickSongItem(pos);
                } else if (radioType == CheckItemType.ARTIST_RADIO_TYPE) {
                    clickArtistItem(radioType, pos);
                } else if (radioType == CheckItemType.ALBUM_RADIO_TYPE) {
                    clickAlbumItem(radioType, pos);
                } else if (radioType == CheckItemType.SONGLIST_RADIO_TYPE) {
                    clickSongListItem(radioType, pos);
                }
            }

            @Override
            public void onMoreClick(int pos, LPMSLibraryPlayItem item) {
                nextPlay(pos, item);
            }
        });

        tab_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (checkedId == song_radio.getId()) {
                    if (songlistList != null && songlistList.size() > 0)
                        uihd.sendEmptyMessage(UPDATE_SONGS_LIST);
                    else
                        searchMusics();
                } else if (checkedId == artist_radio.getId()) {
                    if (artistList != null && artistList.size() > 0)
                        uihd.sendEmptyMessage(UPDATE_ARTIST_LIST);
                    else
                        searchArtist();
                } else if (checkedId == album_radio.getId()) {
                    if (albumList != null && albumList.size() > 0)
                        uihd.sendEmptyMessage(UPDATE_ALBUM_LIST);
                    else
                        searchAlbums();
                } else if (checkedId == songlist_radio.getId())
                    if (songlistList != null && songlistList.size() > 0)
                        uihd.sendEmptyMessage(UPDATE_SONGLIST_LIST);
                    else
                        searchSonglists();
            }
        });

        initPlayHeader();

        searchMusics();

        recyclerview.setAdapter(adapter);

        return cview;
    }

    private void initPlayHeader() {

        if (songsPlayHeader == null)
            songsPlayHeader = new LPPlayHeader();
        songsPlayHeader.setCurrentPage(1);
        songsPlayHeader.setPerPage(50);

        if (artistPlayHeader == null)
            artistPlayHeader = new LPPlayHeader();
        artistPlayHeader.setCurrentPage(1);
        artistPlayHeader.setPerPage(50);

        if (albumPlayHeader == null)
            albumPlayHeader = new LPPlayHeader();
        albumPlayHeader.setCurrentPage(1);
        albumPlayHeader.setPerPage(50);

        if (songlistPlayHeader == null)
            songlistPlayHeader = new LPPlayHeader();
        songlistPlayHeader.setCurrentPage(1);
        songlistPlayHeader.setPerPage(50);
    }

    @Override
    public void onResume() {
        super.onResume();

        mLPDevice = UIApplication.currDevice;

        LPDeviceObserverManager.getInstance().register(this);
    }

    private void test(){
    }

    @Override
    public void onPause() {
        super.onPause();

        LPDeviceObserverManager.getInstance().unregister(this);
    }

    private void searchMusics() {

        LPMSLibraryManager.getInstance(UIApplication.instance).searchSongs(songsPlayHeader,
                new LPSearchMediaResultListener() {
                    @Override
                    public void success(LPPlayMusicList musicList) {

                        if (musicList != null) {

                            List<LPPlayItem> playItemList = musicList.getList();
                            if (playItemList != null) {

                                Object[] items = playItemList.toArray();
                                List<Object> objectList = Arrays.asList(items);
                                List<LPMSLibraryPlayItem> locPlayItemList = (List) objectList;

                                if (songsList == null)
                                    songsList = new ArrayList<>();

                                songsList.addAll(locPlayItemList);
                            }

                            songsPlayHeader = musicList.getHeader();

                            //songsPlayHeader.setCurrentPage(songsPlayHeader.getCurrentPage() + 1);
                        }

                        uihd.sendEmptyMessage(UPDATE_SONGS_LIST);

                        new Thread(new Runnable() {
                            @Override
                            public void run() {


                                for (int i = 0; i < songsList.size(); i++) {
                                    LPMSLibraryPlayItem tmpAlbum = songsList.get(i);
                                    if (tmpAlbum == null)
                                        continue;

                                    tmpAlbum.setTrackImage(LPMSLibraryManager.getInstance(UIApplication.instance)
                                            .getAlbumArt(tmpAlbum));
                                }
                            }
                        }).start();
                    }

                    @Override
                    public void failure(Exception e) {
                    }
                });


    }

    private void searchArtist() {
        LPMSLibraryManager.getInstance(UIApplication.instance).searchArtists(artistPlayHeader,
                new LPSearchMediaResultListener() {

                    @Override
                    public void success(LPPlayMusicList musicList) {

                        if (musicList != null) {

                            List<LPPlayItem> playItemList = musicList.getList();
                            if (playItemList != null) {

                                Object[] items = playItemList.toArray();
                                List<Object> objectList = Arrays.asList(items);
                                List<LPMSLibraryPlayItem> locPlayItemList = (List) objectList;

                                if (artistList == null)
                                    artistList = new ArrayList<>();

                                artistList.addAll(locPlayItemList);
                            }

                            artistPlayHeader = musicList.getHeader();

                            //artistPlayHeader.setCurrentPage(artistPlayHeader.getCurrentPage() + 1);
                        }

                        uihd.sendEmptyMessage(UPDATE_ARTIST_LIST);
                    }

                    @Override
                    public void failure(Exception e) {

                     }
                });
    }

    private void searchAlbums() {

        LPMSLibraryManager.getInstance(UIApplication.instance).searchAlbums(albumPlayHeader,
                new LPSearchMediaResultListener() {

                    @Override
                    public void success(LPPlayMusicList musicList) {

                        if (musicList != null) {

                            List<LPPlayItem> playItemList = musicList.getList();
                            if (playItemList != null) {

                                Object[] items = playItemList.toArray();
                                List<Object> objectList = Arrays.asList(items);
                                List<LPMSLibraryPlayItem> locPlayItemList = (List) objectList;

                                if (albumList == null)
                                    albumList = new ArrayList<>();

                                albumList.addAll(locPlayItemList);
                            }

                            albumPlayHeader = musicList.getHeader();

                            //albumPlayHeader.setCurrentPage(albumPlayHeader.getCurrentPage() + 1);
                        }

                        uihd.sendEmptyMessage(UPDATE_ALBUM_LIST);
                    }

                    @Override
                    public void failure(Exception e) {

                     }
                });
    }

    private void searchSonglists() {

        LPMSLibraryManager.getInstance(UIApplication.instance).searchSonglists(songlistPlayHeader,
                new LPSearchMediaResultListener() {

                    @Override
                    public void success(LPPlayMusicList musicList) {

                        if (musicList != null) {

                            List<LPPlayItem> playItemList = musicList.getList();
                            if (playItemList != null) {

                                Object[] items = playItemList.toArray();
                                List<Object> objectList = Arrays.asList(items);
                                List<LPMSLibraryPlayItem> locPlayItemList = (List) objectList;

                                if (songlistList == null)
                                    songlistList = new ArrayList<>();

                                songlistList.addAll(locPlayItemList);
                            }

                            songlistPlayHeader = musicList.getHeader();

                            //songlistPlayHeader.setCurrentPage(songlistPlayHeader.getCurrentPage() + 1);
                        }

                        uihd.sendEmptyMessage(UPDATE_SONGLIST_LIST);
                    }

                    @Override
                    public void failure(Exception e) {

                     }
                });
    }

    private String getMediaData(int pos, boolean nextPlay) {

        List<LPMSLibraryPlayItem> mediaInfoList = null;
        if(nextPlay)
            mediaInfoList = Arrays.asList(adapter.getCurrList().get(pos));
        else
            mediaInfoList = adapter.getCurrList();

        LPPlayHeader playHeader = new LPPlayHeader();
        if(nextPlay)
            playHeader.setHeadTitle(LPPlayQueueType.LP_CURRENT_QUEUE.getValue());
        else
            playHeader.setHeadTitle("My Music");

        playHeader.setMediaType(LPPlayHeader.LPPlayMediaType.LP_SONGLIST_LOCAL);
        playHeader.setMediaSource(LPPlaySourceType.LP_LOCALMUSIC);

        LPPlayMusicList lpPlayMusicList = new LPPlayMusicList();
        lpPlayMusicList.setHeader(playHeader);
        lpPlayMusicList.setIndex(pos);
        lpPlayMusicList.setList(mediaInfoList);

        String data = LPMDPKitManager.getInstance().playMusicSingleSource(lpPlayMusicList);

        return data;
    }

    private void nextPlay(int pos, LPMSLibraryPlayItem item){

        String mediaData = getMediaData(pos, true);

        LPMediaInfo mediaInfo = new LPMediaInfo();
        mediaInfo.setAlbum(item.getAlbumName());
        mediaInfo.setArtist(item.getTrackArtist());
        mediaInfo.setTitle(item.getTrackName());

        UIApplication.currDevice.getPlayer().nextPlay(mediaData,
                mediaInfo,
                new LPDevicePlayerListener() {
                    @Override
                    public void onSuccess(String result) {

                        uihd.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "next play success", Toast.LENGTH_SHORT).show();
                            }
                        });

                        Log.i(TAG, "success");
                    }

                    @Override
                    public void onFailure(Exception e) {
                        uihd.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "next play failed", Toast.LENGTH_SHORT).show();
                            }
                        });

                        Log.i(TAG, "failed");
                    }
                });
    }

    private void clickSongItem(int pos) {

        String mediaData = getMediaData(pos, false);

        UIApplication.currDevice.getPlayer().playAudio(mediaData,
                new LPDevicePlayerListener() {

                    @Override
                    public void onSuccess(String result) {


                        Intent intent = new Intent(getActivity(), PlayControlActivity.class);
                        startActivity(intent);
                    }

                    @Override
                    public void onFailure(Exception e) {
                     }
                });
    }

    private void clickArtistItem(CheckItemType type, int pos) {

        LPMSLibraryPlayItem mediaInfoList = adapter.getCurrList().get(pos);

        FragLocMusicDetails vfrag = new FragLocMusicDetails();
        artistPlayHeader.setHeadTitle(mediaInfoList.getTrackArtist());
        vfrag.setPlayItem(type, mediaInfoList);

        FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);
    }


    private void clickAlbumItem(CheckItemType type, int pos) {

        LPMSLibraryPlayItem mediaInfoList = adapter.getCurrList().get(pos);

        FragLocMusicDetails vfrag = new FragLocMusicDetails();
        vfrag.setPlayItem(type, mediaInfoList);

        FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);
    }

    private void clickSongListItem(CheckItemType type, int pos) {

        LPMSLibraryPlayItem mediaInfoList = adapter.getCurrList().get(pos);

        FragLocMusicDetails vfrag = new FragLocMusicDetails();
        vfrag.setPlayItem(type, mediaInfoList);

        FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);
    }

    @Override
    public void updateDeviceInfo(LPNotification notification) {

        if (notification.getUuid().equals(UIApplication.currDevice.getUpnpUUID()))
                ;
    }

    @Override
    public void onBack() {
        super.onBack();
        FragUtil.popBack(getActivity());
    }
}
