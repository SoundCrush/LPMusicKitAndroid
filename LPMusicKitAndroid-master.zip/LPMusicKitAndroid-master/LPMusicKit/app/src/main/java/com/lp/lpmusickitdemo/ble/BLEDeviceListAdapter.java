package com.lp.lpmusickitdemo.ble;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.lp.ble.entity.LPBluetoothDevice;
import com.lp.lpmusickitdemo.R;

import java.util.ArrayList;

public class BLEDeviceListAdapter extends RecyclerView.Adapter<BLEDeviceListAdapter.HolderView> {

    private ArrayList<LPBluetoothDevice> deviceList = new ArrayList<>();
    private Context context;

    public BLEDeviceListAdapter(Context context) {
        this.context = context;
    }

    public ArrayList<LPBluetoothDevice> getDeviceList() {
        return deviceList;
    }

    public void setDeviceList(ArrayList<LPBluetoothDevice> deviceList) {
        this.deviceList = deviceList;
    }

    public void clear() {
        if (deviceList != null)
            deviceList.clear();

        notifyDataSetChanged();
    }

    @Override
    public HolderView onCreateViewHolder(ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_ble_device, null);

        HolderView holderView = new HolderView(view);

        return holderView;
    }

    @Override
    public void onBindViewHolder(HolderView holderView, final int i) {

        final LPBluetoothDevice device = deviceList.get(i);

        holderView.tv_title.setText(device.getBluetoothDevice().getName());
        if (TextUtils.isEmpty(device.getBluetoothDevice().getName())) {
            holderView.tv_title.setText("UNKNOWN NAME");
        }

        holderView.item_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                notifyDataSetChanged();
                if (itemClickListener != null) {
                    itemClickListener.onItemClick(device, i);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return deviceList == null ? 0 : deviceList.size();
    }

    private OnBleItemClickListener itemClickListener;

    public void setItemClickListener(OnBleItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public interface OnBleItemClickListener {
        void onItemClick(LPBluetoothDevice bluetoothDevice, int pos);
    }

    public static class HolderView extends RecyclerView.ViewHolder {

        TextView tv_title;
        RelativeLayout item_layout;

        public HolderView(View itemView) {
            super(itemView);

            item_layout = itemView.findViewById(R.id.item_layout);
            tv_title = itemView.findViewById(R.id.tv_title);
        }
    }
}
