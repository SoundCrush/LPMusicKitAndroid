package com.lp.lpmusickitdemo.ble;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.linkplay.core.app.LPDeviceManager;
import com.linkplay.core.device.LPDevice;
import com.lp.ble.entity.LPBluetoothDevice;
import com.lp.ble.manager.ApItem;
import com.lp.ble.manager.BLEConnectApResult;
import com.lp.ble.manager.LPBLEManager;
import com.lp.ble.manager.LPConnectWiFiListener;
import com.lp.ble.utils.BLEProfile;
import com.lp.lpmusickitdemo.FragBase;
import com.lp.lpmusickitdemo.FragUtil;
import com.lp.lpmusickitdemo.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Timer;
import java.util.TimerTask;

public class FragBLEDeviceConnecting extends FragBase {

    private static final String TAG = "FragBLEDeviceConnecting";

    LPBluetoothDevice bluetoothDevice;

    private Timer checkOnlineTimer;//check online Timer
    private Timer connTimer;//BLE connect Timer

    private boolean startConnect = false;
    private String pwd;
    private ApItem apItem;

    public void setConnectInfo(ApItem apItem, String pwd) {

        this.apItem = apItem;
        this.pwd = pwd;
    }

    public void setBluetoothDevice(LPBluetoothDevice bluetoothDevice) {
        this.bluetoothDevice = bluetoothDevice;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        cview = inflater.inflate(R.layout.frag_ble_connecting, null);

        return cview;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (startConnect)
            return;

        startConnect = true;

        startConnect();
    }

    @Override
    public void onStop() {
        super.onStop();

        cancelConnTimer();
        cancelCheckTimer();
    }

    /**
     * connect timer
     */
    private void startConnTimer() {
        if (connTimer != null) {
            connTimer.cancel();
        }

        final long startTime = System.currentTimeMillis();
        connTimer = new Timer();
        connTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                long curTime = System.currentTimeMillis();
                if (curTime - startTime > BLEProfile.BLE_CONN_TIME_OUT) {

                    connTimer.cancel();
                    bleHandler.sendEmptyMessage(PAIR_FAILED);
                }
            }
        }, 0, 2000);
    }

    /**
     * send connect command
     */
    private void startConnect() {

        if (bluetoothDevice != null) {

            LPBLEManager.getInstance().connectWLAN(apItem.getSsid(),
                    pwd, apItem.getAuth(), apItem.getEncry(), new LPConnectWiFiListener() {
                        @Override
                        public void LPConnectResult(BLEConnectApResult bleConnectApResult, String s) {

                            Log.i(TAG, "LPConnectResult: " + bleConnectApResult.name());

                            if (bleConnectApResult == BLEConnectApResult.LP_CONNECT_AP_SUCCESS) {

                                try {
                                    JSONObject jsonObject = new JSONObject(s);

                                    String code = "", ip = "", uuid = "";

                                    if(jsonObject.has("code"))
                                        code = jsonObject.getString("code");

                                    if(code.equals("0")) {
                                        if (jsonObject.has("IP"))
                                            ip = jsonObject.getString("IP");

                                        if (jsonObject.has("UUID"))
                                            uuid = jsonObject.getString("UUID");

                                        if (!TextUtils.isEmpty(ip) && !TextUtils.isEmpty(uuid))
                                            connectSuccess(ip, uuid);
                                    }else{
                                        connectFail();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }

                        }

                        @Override
                        public void LPConnectFailed(Exception e) {
                            Log.i(TAG, "LPConnectFailed" + e.getLocalizedMessage());
                            connectFail();
                        }
                    });

            startConnTimer();
        }
    }

    private void cancelConnTimer() {
        if (connTimer != null) {
            connTimer.cancel();
            connTimer = null;
        }
    }

    private void connectSuccess(String ip, String uuid) {

        startConnect = false;

        cancelConnTimer();
        checkDeviceAfterBle(ip, uuid);
    }

    private void connectFail() {

        startConnect = false;

        cancelConnTimer();

        bleHandler.sendEmptyMessage(PAIR_FAILED);
    }

    private void cancelCheckTimer() {
        if (checkOnlineTimer != null) {
            checkOnlineTimer.cancel();
            checkOnlineTimer = null;
        }
    }

    private void checkFailed() {
        if (getActivity() == null) return;
        cancelCheckTimer();
        bleHandler.sendEmptyMessage(PAIR_FAILED);
    }

    private void checkSuccess() {
        cancelCheckTimer();

        int delayTimer = 3 * 1000;

        bleHandler.postDelayed(new Runnable() {
            @Override
            public void run() {

                bleHandler.sendEmptyMessage(PAIR_SUCCESS);
            }
        }, delayTimer);
    }

    /**
     * check device online
     *
     * @param
     */
    private void checkDeviceAfterBle(String ip, final String uuid) {

        if (checkOnlineTimer != null) {
            checkOnlineTimer.cancel();
        }

        final long startTime = System.currentTimeMillis();
        checkOnlineTimer = new Timer();
        checkOnlineTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                long curTime = System.currentTimeMillis();
                if (curTime - startTime > BLEProfile.BLE_CHECK_TIME_OUT) {
                    checkFailed();
                    return;
                }
                LPDevice lpDevice = LPDeviceManager.getInstance().deviceForID(uuid);

                if (lpDevice != null) {
                    checkSuccess();
                }
            }
        }, 500, 1000);
    }

    private static final int CONNECT_FAILED = -2;//connect failed
    private static final int CLOSE_CONNECT = -1;//close connect
    private static final int CONNECT_SUCCESS = 1;//connect success
    private static final int PAIR_SUCCESS = 2;//BLE pair success
    private static final int PAIR_FAILED = 3;//BLE pair failed


    private Handler bleHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case CONNECT_FAILED: {

                    LPBLEManager.getInstance().disConnect();

                    FragBLEConnectFailed vfrag = new FragBLEConnectFailed();
                    FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);

                }
                break;
                case CLOSE_CONNECT:

                    LPBLEManager.getInstance().disConnect();
                    break;
                case CONNECT_SUCCESS:
                    break;
                case PAIR_SUCCESS:
                    if (getActivity() != null && isAdded()) {

                        LPBLEManager.getInstance().disConnect();

                        FragBLEConnectSuccess vfrag = new FragBLEConnectSuccess();
                        FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);

                    }
                    break;
                case PAIR_FAILED:


                    FragBLEConnectFailed vfrag = new FragBLEConnectFailed();
                    FragUtil.addFrag(getActivity(), R.id.vfrag, vfrag, true);

                    break;
            }
        }
    };
}
