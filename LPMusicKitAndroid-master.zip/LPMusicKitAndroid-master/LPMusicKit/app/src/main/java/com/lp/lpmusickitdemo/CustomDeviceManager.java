package com.lp.lpmusickitdemo;

import android.app.Application;
import android.util.Log;

import com.linkplay.core.app.LPDeviceManager;
import com.linkplay.core.app.LPDeviceManagerObserver;
import com.linkplay.core.app.LPDeviceManagerParam;
import com.linkplay.core.device.LPDevice;
import com.linkplay.lpmdpkit.callback.LPPrintLogCallback;
import com.linkplay.lpmdpkit.utils.LPLogUtil;

import org.greenrobot.eventbus.EventBus;

/**
 * @author linkplay
 * @version v1.0
 * @date 2019/07/31 17:50
 * @Description: TODO{}
 */
public class CustomDeviceManager implements LPDeviceManagerObserver, LPPrintLogCallback {

    private static final String TAG = "CustomDeviceManager";

    private Application context;

    public CustomDeviceManager(Application context) {

        this.context = context;

        LPLogUtil.init(this);

        LPDeviceManagerParam param = new LPDeviceManagerParam();
        param.context = context;
        param.appid = "";

        LPDeviceManager lpDeviceManager = LPDeviceManager.getInstance();
        lpDeviceManager.init(param);
        lpDeviceManager.addObserver(this);

//        lpDeviceManager.search(new String[]{"ssdp:yamaha", "ssdp:wiimudevice"});//自定义音箱搜索字段
        lpDeviceManager.search(null);
    }

    @Override
    public void LPDeviceOnline(LPDevice lpDevice) {

        Log.i(TAG, "device add");

        CustomDeviceEventItem item = new CustomDeviceEventItem();
        EventBus.getDefault().post(item);
    }

    @Override
    public void LPDeviceRemove(LPDevice lpDevice) {

        Log.i(TAG, "device remove");

        CustomDeviceEventItem item = new CustomDeviceEventItem();
        EventBus.getDefault().post(item);
    }

    @Override
    public void LPDeviceUpdate(LPDevice lpDevice) {

        Log.i(TAG, "device update");
    }

    @Override
    public void i(String s, String s1) {
        Log.i(s, TAG + " pint i message: " + s1);
    }

    @Override
    public void d(String s, String s1) {
        Log.d(s, TAG + " pint d message: " + s1);
    }

    @Override
    public void e(String s, String s1) {
        Log.e(s, TAG + " pint e message: " + s1);
    }

    @Override
    public void v(String s, String s1) {
        Log.v(s, TAG + " pint v message: " + s1);
    }

    @Override
    public void w(String s, String s1) {
        Log.w(s, TAG + " pint w message: " + s1);
    }
}
