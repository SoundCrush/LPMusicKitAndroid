package com.lp.lpmusickitdemo.musicsource.loc_music;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.linkplay.medialib.LPMSLibraryPlayItem;
import com.lp.lpmusickitdemo.R;

import java.util.ArrayList;
import java.util.List;


/**
 * @author linkplay
 * @version v1.0
 * @date 2019/08/21 11:24
 * @Description: TODO{}
 */
public class LocMusicDetailsAdapter extends RecyclerView.Adapter<LocMusicDetailsAdapter.LocMusicViewHolder> {

    List<LPMSLibraryPlayItem> currList = new ArrayList<>();

    private Context mContext;

    public LocMusicDetailsAdapter(Context context) {
        mContext = context;
    }

    public void setCurrList(List<LPMSLibraryPlayItem> list) {
        this.currList = list;
    }

    public List<LPMSLibraryPlayItem> getCurrList() {
        return currList;
    }

    @NonNull
    @Override
    public LocMusicViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int pos) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item_loc_music_details, null);

        LocMusicViewHolder viewHolder = new LocMusicViewHolder(view);

        return viewHolder;
    }

    @SuppressLint("NewApi")
    @Override
    public void onBindViewHolder(@NonNull LocMusicViewHolder locMusicViewHolder, final int pos) {

        LPMSLibraryPlayItem data = currList.get(pos);

        locMusicViewHolder.tv_title.setText(data.getTrackName());
        locMusicViewHolder.tv_sub_title.setText(data.getTrackArtist());

        locMusicViewHolder.container.setBackground(mContext.getDrawable(R.drawable.selector_item_bg));

        locMusicViewHolder.iv_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener != null)
                    listener.onMoreClick(pos, data);
            }
        });

        locMusicViewHolder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (listener != null)
                    listener.onItemClick(pos);
            }
        });
    }

    @Override
    public int getItemCount() {

        return currList == null ? 0 : currList.size();
    }


    private IOnItemClickListener listener;

    public void setOnItemClickListener(IOnItemClickListener listener) {
        this.listener = listener;
    }

    public interface IOnItemClickListener {
        void onItemClick(int pos);
        void onMoreClick(int pos, LPMSLibraryPlayItem item);
    }

    public static class LocMusicViewHolder extends RecyclerView.ViewHolder {

        public View container;
        public TextView tv_title, tv_sub_title;
        public ImageView iv_more;

        public LocMusicViewHolder(@NonNull View itemView) {
            super(itemView);

            container = itemView;
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_sub_title = itemView.findViewById(R.id.tv_sub_title);
            iv_more = itemView.findViewById(R.id.iv_more);
        }
    }

}
