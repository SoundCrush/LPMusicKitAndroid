package com.lp.lpmusickitdemo.util.glide;

import android.content.Context;

import java.io.File;

/**
 * @author leyunrui-wiimu
 * @version v1.0
 * @date 下午2:41 18-07-2017
 * @Description: TODO{}
 */

public class PathUtils {

    public static String IMG_DIR = "cache_dir";

    public static File getDiskCacheDir(Context context, String img_dir){

        File cacheLocation = new File(context.getExternalCacheDir(), img_dir);
        if(cacheLocation != null){
            if(cacheLocation.exists() == false){
                cacheLocation.mkdirs();
            }
            return cacheLocation;
        }else{
            return null;
        }
    }
}
