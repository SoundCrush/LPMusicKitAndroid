package com.lp.lpmusickitdemo.musicsource;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.linkplay.core.listener.LPDevicePlayerListener;
import com.linkplay.core.status.LPPlayChannel;
import com.linkplay.core.status.LPPlayMode;
import com.linkplay.core.status.LPPlayStatus;
import com.linkplay.core.status.LPSpotifyPlayMode;
import com.linkplay.lpmdpkit.bean.LPPlayHeader;
import com.linkplay.lpmdpkit.observer.LPDeviceInfoObservable;
import com.linkplay.lpmdpkit.observer.LPDeviceMediaInfoObservable;
import com.linkplay.lpmdpkit.observer.LPDeviceObserverManager;
import com.linkplay.lpmdpkit.observer.LPNotification;
import com.linkplay.lpmdpkit.observer.LPNotificationType;
import com.linkplay.medialib.server.MediaServer;
import com.lp.lpmusickitdemo.R;
import com.lp.lpmusickitdemo.UIApplication;
import com.lp.lpmusickitdemo.util.ToolsUtil;
import com.lp.lpmusickitdemo.util.glide.GlideMgtUtil;
import com.lp.lpmusickitdemo.util.glide.ImageLoadConfig;

public class PlayControlActivity extends FragmentActivity implements
        LPDeviceMediaInfoObservable, LPDeviceInfoObservable {

    private static final String TAG = "PlayControlActivity";

    ImageView iv_album;
    TextView tv_song_title, tv_artist, tv_curr_time, tv_total_time;
    SeekBar seekbar_time, seekbar_volume;
    Button btn_mode, btn_prev, btn_play, btn_next;

    private static final int BTN_PLAY_STATUS = 1;//播放按钮
    private static final int BTN_PAUSE_STATUS = 2;//暂停按钮
    private static final int UPDATE_PLAY_TIME = 3;//更新播放进度
    private static final int UPDATE_MEDIA_INFO = 4;//更新播放媒体信息

    Handler uihd = new Handler(Looper.getMainLooper()) {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            int what = msg.what;

            if (what == BTN_PLAY_STATUS) {

                Log.i(TAG, "playStatus: Pause");

                btn_play.setTag(BTN_PLAY_STATUS);
                btn_play.setText("Pause");

            } else if (what == BTN_PAUSE_STATUS) {

                Log.i(TAG, "playStatus: Play");

                btn_play.setTag(BTN_PAUSE_STATUS);
                btn_play.setText("Play");
            } else if (what == UPDATE_PLAY_TIME) {

                if (UIApplication.currDevice == null)
                    return;
                long tickTime = UIApplication.currDevice.getMediaInfo().getTickTime();
                long totalTime = UIApplication.currDevice.getMediaInfo().getTotalTime();

                tv_curr_time.setText(ToolsUtil.getTimeTick(tickTime));
                tv_total_time.setText(ToolsUtil.getTimeTick(totalTime));

                seekbar_time.setMax((int) totalTime);
                seekbar_time.setProgress((int) tickTime);
            } else if (what == UPDATE_MEDIA_INFO) {

                tv_song_title.setText(UIApplication.currDevice.getMediaInfo().getTitle());
                tv_artist.setText(UIApplication.currDevice.getMediaInfo().getArtist());

                setAlbumImage(UIApplication.currDevice.getMediaInfo().getAlbumArtURI());
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        setContentView(R.layout.play_control_activity);

        iv_album = findViewById(R.id.iv_album);
        tv_song_title = findViewById(R.id.tv_song_title);
        tv_artist = findViewById(R.id.tv_artist);
        tv_curr_time = findViewById(R.id.tv_curr_time);
        tv_total_time = findViewById(R.id.tv_total_time);
        seekbar_time = findViewById(R.id.seekbar_time);
        seekbar_volume = findViewById(R.id.seekbar_volume);
        btn_mode = findViewById(R.id.btn_mode);
        btn_prev = findViewById(R.id.btn_prev);
        btn_play = findViewById(R.id.btn_play);
        btn_next = findViewById(R.id.btn_next);


        uihd.sendEmptyMessage(BTN_PAUSE_STATUS);

        uihd.sendEmptyMessage(UPDATE_PLAY_TIME);

        bindSlots();
    }

    private void bindSlots() {
        btn_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ((int) v.getTag() == BTN_PLAY_STATUS) {
                    uihd.sendEmptyMessage(BTN_PAUSE_STATUS);

                    UIApplication.currDevice.getPlayer().pause(new LPDevicePlayerListener() {
                        @Override
                        public void onSuccess(String result) {
                            Log.i(TAG, "pause success: " + result);
                        }

                        @Override
                        public void onFailure(Exception e) {
                            Log.i(TAG, "pause fail: " + e.getMessage());
                        }
                    });
                } else {
                    uihd.sendEmptyMessage(BTN_PLAY_STATUS);

                    UIApplication.currDevice.getPlayer().play(new LPDevicePlayerListener() {
                        @Override
                        public void onSuccess(String result) {
                            Log.i(TAG, "play success: " + result);
                        }

                        @Override
                        public void onFailure(Exception e) {
                            Log.i(TAG, "play fail: " + e.getMessage());
                        }
                    });
                }
            }
        });


        btn_prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                UIApplication.currDevice.getPlayer().previous(new LPDevicePlayerListener() {
                    @Override
                    public void onSuccess(String result) {
                        Log.i(TAG, "previous success: " + result);
                    }

                    @Override
                    public void onFailure(Exception e) {
                        Log.i(TAG, "previous fail: " + e.getMessage());
                    }
                });
            }
        });

        btn_next.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                UIApplication.currDevice.getPlayer().next(new LPDevicePlayerListener() {
                    @Override
                    public void onSuccess(String result) {
                        Log.i(TAG, "next success: " + result);
                    }

                    @Override
                    public void onFailure(Exception e) {
                        Log.i(TAG, "next fail: " + e.getMessage());
                    }
                });
            }
        });

        btn_mode.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (UIApplication.currDevice.getMediaInfo().getMediaType().equals(LPPlayHeader.LPPlayMediaType.LP_SPOTIFY)) {

                    LPSpotifyPlayMode lpSpotifyPlayMode = UIApplication.currDevice.getDeviceInfo().getSpotifyPlayMode();

                    LPSpotifyPlayMode setLPSpotifyPlayMode = null;

                    switch (lpSpotifyPlayMode) {
                        case LP_SPOTIFY_DEFAULT:
                            setLPSpotifyPlayMode = LPSpotifyPlayMode.LP_SPOTIFY_LISTREPEAT;
                            break;
                        case LP_SPOTIFY_SHUFFLE:
                            setLPSpotifyPlayMode = LPSpotifyPlayMode.LP_SPOTIFY_SINGLEREPEAT;
                            break;
                        case LP_SPOTIFY_LISTREPEAT:
                            setLPSpotifyPlayMode = LPSpotifyPlayMode.LP_SPOTIFY_SHUFFLEREPEAT;
                            break;
                        case LP_SPOTIFY_SINGLEREPEAT:
                            setLPSpotifyPlayMode = LPSpotifyPlayMode.LP_SPOTIFY_SINGLE_REPEAT_SHUFFLE;
                            break;
                        case LP_SPOTIFY_SHUFFLEREPEAT:
                            setLPSpotifyPlayMode = LPSpotifyPlayMode.LP_SPOTIFY_SHUFFLE;
                            break;
                        case LP_SPOTIFY_SINGLE_REPEAT_SHUFFLE:
                            setLPSpotifyPlayMode = LPSpotifyPlayMode.LP_SPOTIFY_DEFAULT;
                            break;
                        default:
                            setLPSpotifyPlayMode = LPSpotifyPlayMode.LP_SPOTIFY_DEFAULT;
                    }

                    UIApplication.currDevice.getPlayer()
                            .setSpotifyPlayMode(setLPSpotifyPlayMode,
                                    new LPDevicePlayerListener() {
                                        @Override
                                        public void onSuccess(String result) {
                                            Log.i(TAG, "setMode success: " + result);
                                        }

                                        @Override
                                        public void onFailure(Exception e) {
                                            Log.i(TAG, "setMode fail: " + e.getMessage());
                                        }
                                    });
                } else {

                    LPPlayMode lpPlayMode = UIApplication.currDevice.getDeviceInfo().getPlayMode();

                    LPPlayMode setLPPlayMode = null;

                    switch (lpPlayMode) {
                        case LP_DEFAULT:
                            setLPPlayMode = LPPlayMode.LP_LISTREPEAT;
                            break;
                        case LP_LISTREPEAT:
                            setLPPlayMode = LPPlayMode.LP_SINGLEREPEAT;
                            break;
                        case LP_SHUFFLE:
                            setLPPlayMode = LPPlayMode.LP_DEFAULT;
                            break;
                        case LP_SINGLEREPEAT:
                            setLPPlayMode = LPPlayMode.LP_SHUFFLEREPEAT;
                            break;
                        case LP_SHUFFLEREPEAT:
                            setLPPlayMode = LPPlayMode.LP_SHUFFLE;
                            break;
                        default:
                            setLPPlayMode = LPPlayMode.LP_DEFAULT;
                    }

                    UIApplication.currDevice.getPlayer()
                            .setPlayMode(setLPPlayMode,
                                    new LPDevicePlayerListener() {

                                        @Override
                                        public void onSuccess(String result) {
                                            Log.i(TAG, "setMode success: " + result);
                                        }

                                        @Override
                                        public void onFailure(Exception e) {
                                            Log.i(TAG, "setMode fail: " + e.getMessage());
                                        }
                                    });
                }
            }
        });

        seekbar_time.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                if (!fromUser)
                    return;

                UIApplication.currDevice.getPlayer().setProgress(progress, new LPDevicePlayerListener() {
                    @Override
                    public void onSuccess(String result) {
                        Log.i(TAG, "seekbar_time success: " + result);
                    }

                    @Override
                    public void onFailure(Exception e) {
                        Log.i(TAG, "seekbar_time fail: " + e.getMessage());
                    }
                });
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekbar_volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                if (!fromUser)
                    return;

                UIApplication.currDevice.getPlayer().setVolume(progress, new LPDevicePlayerListener() {
                    @Override
                    public void onSuccess(String result) {
                        Log.i(TAG, "seekbar_volume success: " + result);
                    }

                    @Override
                    public void onFailure(Exception e) {
                        Log.i(TAG, "seekbar_volume fail: " + e.getMessage());
                    }
                });
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();

        LPDeviceObserverManager.getInstance().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();

        LPDeviceObserverManager.getInstance().unregister(this);
    }

    private void setAlbumImage(String albumArtURI) {

        if (TextUtils.isEmpty(albumArtURI)) {
            iv_album.setImageDrawable(null);
            iv_album.setImageBitmap(null);
            return;
        }

        String path = albumArtURI.replaceAll("http://" + MediaServer.port, "");

        int size = 80;
        ImageLoadConfig.OverrideSize overrideSize = new ImageLoadConfig.OverrideSize(size, size);
        ImageLoadConfig config3 = ImageLoadConfig.parseBuilder(GlideMgtUtil.defConfig).
                setSkipMemoryCache(false).
                setAsBitmap(true).
                setDiskCacheStrategy(ImageLoadConfig.DiskCache.SOURCE)
                .setSize(overrideSize).
                        build();

        GlideMgtUtil.loadStringRes(UIApplication.instance, iv_album,
                path, config3, null);
    }

    @Override
    public void updateMediaInfo(LPNotification notification) {

        Log.i(TAG, "updateMediaInfo: " + notification.getType());

        if (notification.getUuid().equals(UIApplication.currDevice.getUpnpUUID())) {

            if (notification.getType().equals(LPNotificationType.REAL_TIME_CHANGED)) {

                uihd.sendEmptyMessage(UPDATE_PLAY_TIME);

            } else if (notification.getType().equals(LPNotificationType.META_DATA_CHANGED)) {

                uihd.sendEmptyMessage(UPDATE_MEDIA_INFO);

            } else if (notification.getType().equals(LPNotificationType.VOLUME_CHANED)) {

            } else if (notification.getType().equals(LPNotificationType.TRANSPORT_STATE_CHANGED)) {

            } else if (notification.getType().equals(LPNotificationType.DEVICE_INFO_CHANGE)) {

                if (notification.getUuid().equals(UIApplication.currDevice.getUpnpUUID())) {

                    LPPlayStatus playStatus = UIApplication.currDevice.getDeviceInfo().getPlayStatus();

                    if (playStatus == LPPlayStatus.LP_PLAY_STATUS_PLAYING) {

                        if ((int) btn_play.getTag() == BTN_PLAY_STATUS)
                            return;

                        uihd.sendEmptyMessage(BTN_PLAY_STATUS);
                    } else {

                        if ((int) btn_play.getTag() == BTN_PAUSE_STATUS)
                            return;

                        uihd.sendEmptyMessage(BTN_PAUSE_STATUS);
                    }
                }
            }
        }
    }

    /**
     * Sample
     */
    private void updateBtnStatusUI() {

        if (com.linkplay.core.utils.ToolsUtil.isSpotifyTrackSource(UIApplication.currDevice)) {
            if(ToolsUtil.isFreeSpotifyAccount(UIApplication.currDevice)){
                btn_next.setEnabled(true);
                btn_mode.setEnabled(true);
            } else {
                btn_next.setEnabled(false);
                btn_mode.setEnabled(false);
            }
        } else {
            btn_next.setEnabled(true);
            btn_mode.setEnabled(true);
        }
    }

    @Override
    public void updateDeviceInfo(LPNotification notification) {

        Log.i(TAG, "updateDeviceInfo: " + notification.getType());


        if (notification.getUuid().equals(UIApplication.currDevice.getUpnpUUID())) {

            if (notification.getType().equals(LPNotificationType.DEVICE_INFO_CHANGE)) {

                LPPlayStatus playStatus = UIApplication.currDevice.getDeviceInfo().getPlayStatus();

                if (playStatus == LPPlayStatus.LP_PLAY_STATUS_PLAYING) {

                    if ((int) btn_play.getTag() != BTN_PLAY_STATUS)
                        uihd.sendEmptyMessage(BTN_PLAY_STATUS);
                } else if (playStatus == LPPlayStatus.LP_PLAY_STATUS_PAUSED_PLAYBACK
                        || playStatus == LPPlayStatus.LP_PLAY_STATUS_STOPPED) {

                    if ((int) btn_play.getTag() != BTN_PAUSE_STATUS)
                        uihd.sendEmptyMessage(BTN_PAUSE_STATUS);
                }

                //update play status
                uihd.post(() -> {
                    updateBtnStatusUI();
                });

            } else if (notification.getType().equals(LPNotificationType.CHANNEL_CHANGED)) {

                LPPlayChannel playChannel = UIApplication.currDevice.getDeviceInfo().getPlayChannel();
                if (playChannel == LPPlayChannel.LP_CHANNEL_LEFT)
                    Log.i(TAG, "LP_CHANNEL_LEFT");
                else if (playChannel == LPPlayChannel.LP_CHANNEL_RIGHT)
                    Log.i(TAG, "LP_CHANNEL_RIGHT");
                else if (playChannel == LPPlayChannel.LP_CHANNEL_STEREO)
                    Log.i(TAG, "LP_CHANNEL_STEREO");
            } else if (notification.getType().equals(LPNotificationType.PLAYMODE_CHANGED)){

                LPPlayMode lpPlayMode = UIApplication.currDevice.getDeviceInfo().getPlayMode();
                Log.i(TAG, "Play Mode: " + lpPlayMode);
            }
        }
    }
}
