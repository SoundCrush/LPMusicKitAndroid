package com.lp.lpmusickitdemo.setting;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.lp.lpmusickitdemo.R;

import java.util.ArrayList;
import java.util.List;

public class DeviceSettingAdapter extends RecyclerView.Adapter<DeviceSettingAdapter.ViewHolder> {

    private Context mContext;
    List<DeviceSettingItem> currList = new ArrayList<>();

    public DeviceSettingAdapter(Context context) {
        mContext = context;
    }

    public void setCurrList(List<DeviceSettingItem> list) {
        currList = list;
    }

    public List<DeviceSettingItem> getCurrList() {
        return currList;
    }

    public DeviceSettingItem getItem(DeviceSettingItem.ENUM_TYPE itemtype) {

        if (currList == null || currList.size() == 0)
            return null;

        for (DeviceSettingItem item : currList) {
            if (item.type == itemtype) {
                return item;
            }
        }

        return null;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item_device_setting, null);

        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final DeviceSettingItem item = currList.get(position);

        holder.btn_status.setText(item.strBtnText);
        holder.tv_label.setText(item.strLabel + item.strValue);

        holder.btn_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (listener != null) {
                    listener.onBtnClick(item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {

        return currList == null ? 0 : currList.size();
    }

    private IOnItemClickImpl listener;

    public interface IOnItemClickImpl {
        void onBtnClick(DeviceSettingItem item);
    }

    public void setOnItemClickListener(IOnItemClickImpl listener) {
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public View containerView;
        Button btn_status;
        TextView tv_label;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            containerView = itemView;

            btn_status = itemView.findViewById(R.id.btn_status);
            tv_label = itemView.findViewById(R.id.tv_label);
        }
    }
}
