# LPMusicKitAndroid

[English](https://github.com/linkplayapp/LPMusicKitAndroid/blob/master/README.md) | [中文](https://github.com/linkplayapp/LPMusicKitAndroid/blob/master/README_zh.md)

Linkplay Music Kit is the app side SDK for Linkplay Home Audio solution；you can use it to implement our solution into your product.

MusicKit mainly solves 2 issues：

- Maintain the commnunication protocol with our firmware so that your app could interact with the device without concerning the comlexity of the lower layers.

- Wrapper the complexity of cloud services (includes music services and voice services etc.) so that you can intergtate them rapidly and don't bother the details.

## Documentation
You can find documentation [on the website](https://linkplayapp.github.io/linkplay_sdk_doc/zh-hans/introduction.html).

## How To Get Started
 
##### Step 1: Download LPMusicKitAndroid
- [Download LPMusicKitAndroid](https://github.com/linkplayapp/LPMusicKitAndroid)
##### Step 2: Import SDK
- Refer to the way of importing SDK in Demo to integrate into product engineering
##### Step 3: Import Tripartite Library
##### Step 4: Import dependent libraries
##### Step 5: IDE Setting

## Author
LinkPlay, android_team@linkplay.com