# LPMusicKitAndroid

[English](https://github.com/linkplayapp/LPMusicKitAndroid/blob/master/README.md) | [中文](https://github.com/linkplayapp/LPMusicKitAndroid/blob/master/README_zh.md)

Linkplay Music Kit是Linkplay Home Audio方案的app端SDK；通过它，您可以快速的将我们的解决方案实现到您的产品里。

MusicKit主要解决了两方面的问题：

- 维护与固件的通讯协议，使您可以简洁的与设备进行交互而不必关心琐碎的通讯技术问题

- 封装了网络服务（音乐服务、智能语音服务等）的复杂度，使您可以快速接入它们而不必关心实现细节

## 文档
你可以在这里找到更多[文档](https://linkplayapp.github.io/linkplay_sdk_doc/zh-hans/introduction.html) 。

## 配置项目
 
##### Step 1: 下载LPMusicKitAndroid
- [下载 LPMusicKitAndroid](https://github.com/linkplayapp/LPMusicKitAndroid)
##### Step 2: 导入SDK
- 参考Demo中导入SDK的方式集成到产品工程中
##### Step 3: 导入三方SDK
##### Step 4: 导入依赖库
##### Step 5: 配置IDE开发环境

## 作者
LinkPlay, android_team@linkplay.com